# Deploying Monalisa News (free-tier path)

Vercel (front-end) + Render (API + Postgres + Redis) + Firebase Blaze
(Auth + Gemini Functions). This is the "$0 to start" path discussed in
chat — see that conversation for the real limitations of each free tier
(Render's cold starts, Gemini's rate limits, etc.) before you commit to it
for anything with real traffic.

**Do these in order.** Render and Vercel each need to know the other's
URL, which doesn't exist until you deploy it — so there's a
"deploy once, patch the URL, redeploy" step below. That's not a mistake,
it's just how two independently-hosted services have to be wired.

## 0. Get the code onto GitHub (from a phone)

Every platform below (Vercel, Render, Firebase) deploys **from a GitHub
repo**, not from a zip file directly — so this has to happen first.
GitHub does not extract `.zip` files you upload; it just stores the zip
as a single file. You need to unzip it on your phone first.

**Extract the zip:**
- **iPhone**: open the zip in the **Files** app → tap it → it extracts
  automatically into a folder next to it.
- **Android**: open **Files** / **My Files** → tap the zip → **Extract**
  (built into the default file manager on most Android phones; if yours
  doesn't have this, the free "Files by Google" app does).

**Create the repo:**
1. Go to github.com in your phone's browser (Safari/Chrome — not
   required to use the GitHub app for this part) and sign in.
2. Tap **+** (top right) → **New repository**.
3. Name it (e.g. `monalisa-news`), set it to **Public** or **Private**,
   and **do not** initialize it with a README/`.gitignore`/license —
   leave those boxes unchecked, since you're uploading a repo that
   already has all of that.
4. Create it. You'll land on an empty repo page with an
   **"uploading an existing file"** link — tap that.

**Upload the files:**
5. Tap **choose your files**. Your phone's file picker opens.
6. Navigate to the extracted `monalisa-news-platform` folder.
7. Select everything inside it — on most phones you can tap-hold one item
   to enter selection mode, then **Select All**. Do this per top-level
   item (`.github`, `.gitignore`, `README.md`, `DEPLOY.md`,
   `docker-compose.yml`, `render.yaml`, `api`, `web`, `firebase`) if your
   phone's picker won't select a whole folder tree at once — mobile
   browsers vary here, and this is the one step that's genuinely fiddlier
   on a phone than a laptop.
8. Scroll down, add a commit message like "Initial commit," and tap
   **Commit changes**.
9. Repeat for any folder that didn't come through the first time —
   GitHub's upload page keeps working the same way for follow-up commits.

**If your phone's browser won't let you select a whole folder** (some
Android/iOS browser + file-picker combinations only allow picking
individual files, not folders with their structure intact): the more
reliable option is a real mobile Git client instead of the browser
upload page —
[**Working Copy**](https://workingcopy.app) on iOS or
**Termux + git** on Android can extract the zip and push a proper commit
preserving the full folder structure in one go, which the browser upload
flow sometimes can't guarantee for deeply nested folders. Both are free
to start.

Once the repo has all three folders (`api/`, `web/`, `firebase/`) plus
the root files, you're ready for the actual deploys below — steps 1
through 5 don't care whether the repo got there via phone upload or
`git push` from a laptop, they just need it on GitHub.

## 1. Firebase (do this first — both other services need its config)

1. Create a Firebase project: https://console.firebase.google.com
2. **Upgrade to the Blaze plan** (Project Settings → Usage and billing).
   This sounds like it costs money — it doesn't, by default. Blaze is
   "pay only if you exceed the free quota," and Cloud Functions secrets
   (which `GEMINI_API_KEY` needs) simply aren't available on the free
   Spark plan at all. Put a card on file; you won't be charged unless you
   genuinely exceed the free tier.
3. Enable **Authentication** → Email/Password provider (Build → Authentication → Sign-in method).
4. Get a free Gemini key: https://aistudio.google.com/app/apikey
5. Deploy the AI functions:
   ```bash
   cd firebase/functions
   npm install
   firebase login
   # set your real project ID in ../.firebaserc first
   firebase functions:secrets:set GEMINI_API_KEY
   firebase deploy --only functions
   ```
6. Generate a service account key for the API to verify tokens with:
   Project Settings → Service Accounts → Generate new private key.
   Save the JSON somewhere safe — you'll paste its contents into Render
   in step 2. **Never commit this file.**
7. Get your web app config: Project Settings → General → Your apps → Add
   app (Web) if you haven't. You'll need these six values for step 3.

## 2. Render (API + Postgres + Redis)

1. With the repo on GitHub (step 0), go to the Render dashboard: **New +**
   → **Blueprint**, and connect/point it at that repo. Render will read
   `render.yaml` at the repo root and provision the API, a free Postgres,
   and a free Redis automatically.
2. Before or right after the first deploy, open the `monalisa-news-api`
   service → **Environment**, and set `FIREBASE_SERVICE_ACCOUNT` to the
   **entire contents** of the service account JSON from step 1.6, as one
   line (Render's env var editor handles the JSON fine as a single value).
3. Leave `CORS_ORIGIN` as the placeholder for now — you'll fix it in
   step 4. Deploy.
4. Once it's live, note the URL Render gives you, e.g.
   `https://monalisa-news-api.onrender.com`. Test it:
   ```bash
   curl https://monalisa-news-api.onrender.com/api/v1/categories
   ```
   You should get back the 25 seeded categories as JSON. If you get a
   CORS error later from the browser, that's expected until step 4 — curl
   doesn't enforce CORS, so this check is still valid without it.

## 3. Vercel (front-end)

1. Import this repo in Vercel, set the **root directory to `web`**
   (Vercel needs to know `monalisa-news-nextjs` — renamed `web` inside
   `monalisa-news-platform` — is the actual app, not the repo root).
2. Vercel auto-detects Next.js from `vercel.json` / `package.json` — no
   build command changes needed.
3. Add environment variables (Project Settings → Environment Variables),
   **not** in `vercel.json` since that file is committed to the repo and
   these are effectively secrets:
   - `NEXT_PUBLIC_API_URL` = your Render URL + `/api/v1`, e.g.
     `https://monalisa-news-api.onrender.com/api/v1`
   - `NEXT_PUBLIC_FIREBASE_API_KEY`
   - `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`
   - `NEXT_PUBLIC_FIREBASE_PROJECT_ID`
   - `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`
   - `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`
   - `NEXT_PUBLIC_FIREBASE_APP_ID`
   (the last six come from Firebase step 1.7)
4. Deploy. Note the URL Vercel gives you, e.g. `https://monalisa-news.vercel.app`.

## 4. Close the loop

Go back to Render → `monalisa-news-api` → Environment, and set
`CORS_ORIGIN` to your real Vercel URL from step 3.4 (no trailing slash).
Redeploy the API (Render does this automatically on env var changes, or
trigger it manually).

## 5. Verify

- Visit your Vercel URL. The homepage, category pages, markets, etc.
  should all load — most of the site works even if the API call fails,
  since it falls back to bundled mock data (see `resolveCategory` and the
  live-blog page for examples of that pattern).
- Go to `/login`, create an account. This should succeed via Firebase
  directly (front-end never talks to Render for auth itself).
- Go to `/admin/articles/new`, write something in the body field, click
  "Generate summary." This round-trips through Firebase Auth → your
  Cloud Function → Gemini → back to the browser. If it fails, check the
  browser console — the most common cause is `GEMINI_API_KEY` not set as
  a Functions secret, or not being signed in.
- Check `/live-blog` — if Render's API is reachable, you should see a
  small green dot and "Live — updates automatically" under the headline.
- Go to `/article/climate-summit` (one of the 5 fully-seeded articles —
  see `api/prisma/seed.ts`), scroll to Comments, and post one while
  signed in. It should say "submitted — appears once approved" rather
  than showing up immediately (comments start unapproved by design).
- To approve it and see it appear: promote your own account to
  `EDITOR_IN_CHIEF` or `SUPER_ADMIN` (see the Auth section of
  `api/README.md`), then use `/admin/users` to moderate — or call
  `PATCH /api/v1/comments/:id/moderate` directly.

## What's still a real limitation after all this

Nothing here changes the free-tier ceilings from the chat discussion:
Render's free web service spins down after 15 minutes of inactivity (the
first request after that will be slow — several seconds — while it wakes
back up), and Gemini's free tier has a real requests-per-minute cap. Both
are fine for a demo; neither is fine for a newsroom's actual traffic.
Render's paid tier (~$7/mo) removes the spin-down; Gemini's paid tier is
pay-per-token and cheap for text generation. That's the realistic
"remove the training wheels" upgrade path once this is more than a demo.
