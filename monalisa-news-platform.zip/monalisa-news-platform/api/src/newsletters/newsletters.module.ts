import { Injectable, Module, Controller, Get, Post, Body, UseGuards, ConflictException } from "@nestjs/common";
import { IsString } from "class-validator";
import { PrismaService } from "../prisma/prisma.service";
import { FirebaseAuthGuard } from "../auth/guards/firebase-auth.guard";
import { CurrentUser } from "../auth/decorators/current-user.decorator";
import { AuthModule } from "../auth/auth.module";

class SubscribeDto {
  @IsString()
  newsletterId!: string;
}

@Injectable()
class NewslettersService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.newsletter.findMany();
  }

  async subscribe(userId: string, newsletterId: string) {
    const existing = await this.prisma.newsletterSubscription.findUnique({
      where: { userId_newsletterId: { userId, newsletterId } },
    });
    if (existing) throw new ConflictException("Already subscribed.");
    return this.prisma.newsletterSubscription.create({ data: { userId, newsletterId } });
  }
}

@Controller("newsletters")
class NewslettersController {
  constructor(private newslettersService: NewslettersService) {}

  @Get()
  findAll() {
    return this.newslettersService.findAll();
  }

  @UseGuards(FirebaseAuthGuard)
  @Post("subscribe")
  subscribe(@CurrentUser() user: { id: string }, @Body() dto: SubscribeDto) {
    return this.newslettersService.subscribe(user.id, dto.newsletterId);
  }
}

@Module({
  imports: [AuthModule],
  providers: [NewslettersService],
  controllers: [NewslettersController],
})
export class NewslettersModule {}
