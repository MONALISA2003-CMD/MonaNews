import { Controller, Get, UseGuards } from "@nestjs/common";
import { FirebaseAuthGuard } from "./guards/firebase-auth.guard";
import { CurrentUser } from "./decorators/current-user.decorator";

// Registration and login no longer live here — the Firebase client SDK
// (createUserWithEmailAndPassword / signInWithEmailAndPassword, or any
// other Firebase Auth provider) handles both directly from the front-end.
// This API only ever sees an already-verified ID token.
@Controller("auth")
export class AuthController {
  // Resolves "who am I" from a Firebase ID token, auto-provisioning a
  // newsroom profile row on first call. The front-end calls this right
  // after Firebase sign-in to load role/name/etc.
  @UseGuards(FirebaseAuthGuard)
  @Get("me")
  me(@CurrentUser() user: unknown) {
    return user;
  }
}
