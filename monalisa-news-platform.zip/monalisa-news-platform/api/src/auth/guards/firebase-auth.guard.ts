import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from "@nestjs/common";
import { getAuth } from "firebase-admin/auth";
import { getFirebaseAdminApp } from "../firebase-admin";
import { AuthService } from "../auth.service";

/**
 * Replaces the old JwtAuthGuard. Verifies the Firebase ID token sent as
 * `Authorization: Bearer <token>` (the client SDK's `user.getIdToken()`),
 * then finds-or-creates the matching Prisma User record and attaches it
 * to `request.user` — same contract RolesGuard and @CurrentUser() expect,
 * so nothing downstream needed to change.
 */
@Injectable()
export class FirebaseAuthGuard implements CanActivate {
  constructor(private authService: AuthService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const header: string | undefined = request.headers.authorization;
    const token = header?.startsWith("Bearer ") ? header.slice(7) : null;

    if (!token) throw new UnauthorizedException("Missing bearer token.");

    try {
      const decoded = await getAuth(getFirebaseAdminApp()).verifyIdToken(token);
      request.user = await this.authService.findOrProvisionUser(decoded);
      return true;
    } catch {
      throw new UnauthorizedException("Invalid or expired Firebase ID token.");
    }
  }
}
