import { Injectable } from "@nestjs/common";
import type { DecodedIdToken } from "firebase-admin/auth";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
export class AuthService {
  constructor(private prisma: PrismaService) {}

  /**
   * Every request authenticated by FirebaseAuthGuard lands here. Firebase
   * already verified the person is who they say they are; this just makes
   * sure a matching newsroom profile row exists so the rest of the app
   * (roles, article authorship, saved articles) has something to join
   * against. New accounts default to SUBSCRIBER — promote someone to
   * JOURNALIST/EDITOR/etc. by updating their `role` directly (or build an
   * admin "manage users" screen, which isn't included yet).
   */
  async findOrProvisionUser(decoded: DecodedIdToken) {
    const existing = await this.prisma.user.findUnique({ where: { firebaseUid: decoded.uid } });
    if (existing) return existing;

    return this.prisma.user.create({
      data: {
        firebaseUid: decoded.uid,
        email: decoded.email ?? `${decoded.uid}@no-email.local`,
        name: (decoded.name as string | undefined) ?? decoded.email?.split("@")[0] ?? "New Reader",
        avatarUrl: (decoded.picture as string | undefined) ?? null,
      },
    });
  }
}
