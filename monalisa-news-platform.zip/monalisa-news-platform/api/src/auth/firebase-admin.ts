import { initializeApp, cert, getApps, type App } from "firebase-admin/app";

// Auth on this API now works entirely through Firebase Auth — see
// FirebaseAuthGuard. This is the same Firebase project as
// monalisa-news-firebase and web/src/lib/firebase.ts; all three point at
// one identity provider instead of the API issuing its own JWTs.
//
// Credentials: set GOOGLE_APPLICATION_CREDENTIALS to the path of a service
// account JSON key (Firebase Console → Project Settings → Service Accounts
// → Generate new private key), or set FIREBASE_SERVICE_ACCOUNT as the raw
// JSON string (useful for platforms like Railway/Render where you can't
// mount a file). Never commit the key itself.
let app: App;

export function getFirebaseAdminApp(): App {
  if (getApps().length) return getApps()[0];

  const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT;
  app = serviceAccountJson
    ? initializeApp({ credential: cert(JSON.parse(serviceAccountJson)) })
    : initializeApp(); // falls back to GOOGLE_APPLICATION_CREDENTIALS

  return app;
}
