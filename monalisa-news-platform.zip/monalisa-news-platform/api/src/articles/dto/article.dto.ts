import { IsString, IsOptional, IsEnum, IsArray, IsInt, Min } from "class-validator";
import { ArticleStatus } from "@prisma/client";

export class CreateArticleDto {
  @IsString()
  headline!: string;

  @IsOptional()
  @IsString()
  dek?: string;

  @IsString()
  body!: string;

  @IsString()
  categoryId!: string;

  @IsOptional()
  @IsEnum(ArticleStatus)
  status?: ArticleStatus;

  @IsOptional()
  @IsInt()
  @Min(1)
  readingTimeMin?: number;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tagNames?: string[];
}

export class UpdateArticleDto {
  @IsOptional()
  @IsString()
  headline?: string;

  @IsOptional()
  @IsString()
  dek?: string;

  @IsOptional()
  @IsString()
  body?: string;

  @IsOptional()
  @IsEnum(ArticleStatus)
  status?: ArticleStatus;
}
