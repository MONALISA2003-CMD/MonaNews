import { Injectable, NotFoundException } from "@nestjs/common";
import { ArticleStatus } from "@prisma/client";
import { PrismaService } from "../prisma/prisma.service";
import { CreateArticleDto, UpdateArticleDto } from "./dto/article.dto";

@Injectable()
export class ArticlesService {
  constructor(private prisma: PrismaService) {}

  findPublished(params: { categorySlug?: string; skip?: number; take?: number }) {
    const { categorySlug, skip = 0, take = 20 } = params;
    return this.prisma.article.findMany({
      where: {
        status: ArticleStatus.PUBLISHED,
        category: categorySlug ? { slug: categorySlug } : undefined,
      },
      orderBy: { publishedAt: "desc" },
      skip,
      take,
      include: { author: true, category: true, heroImage: true },
    });
  }

  async findBySlug(slug: string) {
    const article = await this.prisma.article.findUnique({
      where: { slug },
      include: { author: true, category: true, heroImage: true, tags: { include: { tag: true } } },
    });
    if (!article) throw new NotFoundException(`Article "${slug}" not found.`);
    return article;
  }

  async create(authorId: string, dto: CreateArticleDto) {
    const slug = slugify(dto.headline);
    const article = await this.prisma.article.create({
      data: {
        slug,
        headline: dto.headline,
        dek: dto.dek,
        body: dto.body,
        status: dto.status ?? ArticleStatus.DRAFT,
        readingTimeMin: dto.readingTimeMin ?? estimateReadingTime(dto.body),
        author: { connect: { id: authorId } },
        category: { connect: { id: dto.categoryId } },
        // dto.tagNames was previously accepted but never used — tags
        // silently never got attached to new articles. Each name is
        // upserted as a Tag, then linked through the ArticleTag join table.
        tags: dto.tagNames?.length
          ? {
              create: dto.tagNames.map((name) => ({
                tag: {
                  connectOrCreate: {
                    where: { name },
                    create: { name },
                  },
                },
              })),
            }
          : undefined,
      },
      include: { tags: { include: { tag: true } } },
    });

    await this.logAudit(authorId, "article.create", article.id, { headline: article.headline, status: article.status });
    return article;
  }

  async update(id: string, editedById: string, dto: UpdateArticleDto) {
    const existing = await this.prisma.article.findUnique({ where: { id } });
    if (!existing) throw new NotFoundException(`Article "${id}" not found.`);

    // Snapshot the previous body before overwriting it — this is what
    // powers the CMS's "Revision History" requirement from the brief.
    await this.prisma.articleRevision.create({
      data: { articleId: id, editedById, snapshot: existing.body },
    });

    const isPublishing = dto.status === ArticleStatus.PUBLISHED && existing.status !== ArticleStatus.PUBLISHED;

    const updated = await this.prisma.article.update({
      where: { id },
      data: {
        ...dto,
        publishedAt: isPublishing ? new Date() : existing.publishedAt,
      },
    });

    // AuditLog existed in the schema since the first CMS pass but nothing
    // ever wrote to it — the "who published/changed what" trail the brief
    // calls for didn't actually exist. Fixed here and in create()/remove().
    await this.logAudit(
      editedById,
      isPublishing ? "article.publish" : "article.update",
      id,
      { previousStatus: existing.status, newStatus: updated.status }
    );
    return updated;
  }

  async remove(id: string, removedById: string) {
    const archived = await this.prisma.article.update({ where: { id }, data: { status: ArticleStatus.ARCHIVED } });
    await this.logAudit(removedById, "article.archive", id, null);
    return archived;
  }

  private logAudit(userId: string, action: string, targetId: string, metadata: object | null) {
    return this.prisma.auditLog.create({ data: { userId, action, targetId, metadata: metadata ?? undefined } });
  }
}

export function slugify(headline: string): string {
  return (
    headline
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "") +
    "-" +
    Date.now().toString(36)
  );
}

export function estimateReadingTime(body: string): number {
  const words = body.trim().split(/\s+/).length;
  return Math.max(1, Math.round(words / 200)); // ~200 wpm
}
