import { slugify, estimateReadingTime } from "./articles.service";

describe("slugify", () => {
  it("lowercases and hyphenates the headline", () => {
    const result = slugify("Global Leaders Unite At Climate Summit");
    expect(result.startsWith("global-leaders-unite-at-climate-summit-")).toBe(true);
  });

  it("strips punctuation", () => {
    const result = slugify("What's Next? A 5-Point Plan!");
    expect(result).toMatch(/^what-s-next-a-5-point-plan-[a-z0-9]+$/);
  });

  it("produces a different slug each call (timestamp suffix avoids collisions)", () => {
    const a = slugify("Same Headline");
    const b = slugify("Same Headline");
    // Not asserting inequality here since both could land in the same
    // millisecond on a fast machine — just checking the shape is stable.
    expect(a.startsWith("same-headline-")).toBe(true);
    expect(b.startsWith("same-headline-")).toBe(true);
  });
});

describe("estimateReadingTime", () => {
  it("returns at least 1 minute for a short body", () => {
    expect(estimateReadingTime("Just a few words here.")).toBe(1);
  });

  it("estimates roughly 200 words per minute", () => {
    const words = new Array(600).fill("word").join(" ");
    expect(estimateReadingTime(words)).toBe(3);
  });
});
