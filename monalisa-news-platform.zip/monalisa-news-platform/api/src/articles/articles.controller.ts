import { Body, Controller, Get, Post, Patch, Delete, Param, Query, UseGuards } from "@nestjs/common";
import { Role } from "@prisma/client";
import { ArticlesService } from "./articles.service";
import { CreateArticleDto, UpdateArticleDto } from "./dto/article.dto";
import { FirebaseAuthGuard } from "../auth/guards/firebase-auth.guard";
import { RolesGuard } from "../auth/guards/roles.guard";
import { Roles } from "../auth/decorators/roles.decorator";
import { CurrentUser } from "../auth/decorators/current-user.decorator";

const NEWSROOM_ROLES = [Role.SUPER_ADMIN, Role.EDITOR_IN_CHIEF, Role.EDITOR, Role.JOURNALIST];

@Controller("articles")
export class ArticlesController {
  constructor(private articlesService: ArticlesService) {}

  // Public — powers the homepage, category pages, and search index.
  @Get()
  findAll(
    @Query("category") categorySlug?: string,
    @Query("skip") skip?: string,
    @Query("take") take?: string
  ) {
    return this.articlesService.findPublished({
      categorySlug,
      skip: skip ? Number(skip) : undefined,
      take: take ? Number(take) : undefined,
    });
  }

  // Public — powers /article/[slug].
  @Get(":slug")
  findOne(@Param("slug") slug: string) {
    return this.articlesService.findBySlug(slug);
  }

  @UseGuards(FirebaseAuthGuard, RolesGuard)
  @Roles(...NEWSROOM_ROLES)
  @Post()
  create(@CurrentUser() user: { id: string }, @Body() dto: CreateArticleDto) {
    return this.articlesService.create(user.id, dto);
  }

  @UseGuards(FirebaseAuthGuard, RolesGuard)
  @Roles(...NEWSROOM_ROLES)
  @Patch(":id")
  update(@Param("id") id: string, @CurrentUser() user: { id: string }, @Body() dto: UpdateArticleDto) {
    return this.articlesService.update(id, user.id, dto);
  }

  // Archiving (not hard-deleting) preserves the audit trail — restricted to senior roles.
  @UseGuards(FirebaseAuthGuard, RolesGuard)
  @Roles(Role.SUPER_ADMIN, Role.EDITOR_IN_CHIEF)
  @Delete(":id")
  remove(@Param("id") id: string, @CurrentUser() user: { id: string }) {
    return this.articlesService.remove(id, user.id);
  }
}
