import { Injectable, Module, Controller, Get, Patch, Param, Body, UseGuards, NotFoundException } from "@nestjs/common";
import { IsEnum } from "class-validator";
import { Role } from "@prisma/client";
import { PrismaService } from "../prisma/prisma.service";
import { FirebaseAuthGuard } from "../auth/guards/firebase-auth.guard";
import { RolesGuard } from "../auth/guards/roles.guard";
import { Roles } from "../auth/decorators/roles.decorator";
import { CurrentUser } from "../auth/decorators/current-user.decorator";
import { AuthModule } from "../auth/auth.module";

class UpdateRoleDto {
  @IsEnum(Role)
  role!: Role;
}

@Injectable()
class UsersService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.user.findMany({
      orderBy: { createdAt: "desc" },
      select: { id: true, name: true, email: true, role: true, beat: true, createdAt: true },
    });
  }

  async updateRole(id: string, role: Role, changedById: string) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User "${id}" not found.`);

    const updated = await this.prisma.user.update({ where: { id }, data: { role } });
    await this.prisma.auditLog.create({
      data: {
        userId: changedById,
        action: "user.role_change",
        targetId: id,
        metadata: { from: user.role, to: role },
      },
    });
    return updated;
  }
}

// Previously the only way to promote someone off SUBSCRIBER was a raw SQL
// UPDATE against the database — this replaces that with a real, role-
// gated screen so promoting a journalist to EDITOR doesn't require
// database access at all.
@Controller("admin/users")
@UseGuards(FirebaseAuthGuard, RolesGuard)
@Roles(Role.SUPER_ADMIN, Role.EDITOR_IN_CHIEF)
class UsersController {
  constructor(private usersService: UsersService) {}

  @Get()
  findAll() {
    return this.usersService.findAll();
  }

  @Patch(":id/role")
  updateRole(@Param("id") id: string, @Body() dto: UpdateRoleDto, @CurrentUser() user: { id: string }) {
    return this.usersService.updateRole(id, dto.role, user.id);
  }
}

@Module({
  imports: [AuthModule],
  providers: [UsersService],
  controllers: [UsersController],
})
export class UsersModule {}
