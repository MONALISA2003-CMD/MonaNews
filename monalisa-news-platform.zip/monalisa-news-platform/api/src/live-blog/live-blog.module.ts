import { Injectable, Module, Controller, Get, Post, Body, Param, UseGuards } from "@nestjs/common";
import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from "@nestjs/websockets";
import { Server, Socket } from "socket.io";
import { IsString, IsOptional } from "class-validator";
import { Role } from "@prisma/client";
import { PrismaService } from "../prisma/prisma.service";
import { FirebaseAuthGuard } from "../auth/guards/firebase-auth.guard";
import { RolesGuard } from "../auth/guards/roles.guard";
import { Roles } from "../auth/decorators/roles.decorator";
import { AuthModule } from "../auth/auth.module";

class CreateEntryDto {
  @IsString()
  title!: string;

  @IsString()
  body!: string;

  @IsOptional()
  @IsString()
  tag?: string;
}

@Injectable()
class LiveBlogService {
  constructor(private prisma: PrismaService) {}

  findBySlug(slug: string) {
    return this.prisma.liveBlog.findUnique({
      where: { slug },
      include: { entries: { orderBy: { postedAt: "desc" } } },
    });
  }

  addEntry(liveBlogId: string, dto: CreateEntryDto) {
    return this.prisma.liveBlogEntry.create({ data: { liveBlogId, ...dto } });
  }
}

// Pushes new entries to connected clients in real time — this is the
// WebSocket piece called for in the brief's tech stack, so the live blog
// page doesn't need to poll.
@WebSocketGateway({ cors: { origin: "*" }, namespace: "/live-blog" })
class LiveBlogGateway {
  @WebSocketServer()
  server!: Server;

  @SubscribeMessage("join")
  handleJoin(@MessageBody() liveBlogSlug: string, @ConnectedSocket() client: Socket) {
    // This was previously a no-op that only returned the slug without ever
    // calling client.join() — broadcastNewEntry() below emits to this room,
    // so no connected client was actually receiving live updates. Fixed.
    client.join(liveBlogSlug);
    return { joined: liveBlogSlug };
  }

  broadcastNewEntry(liveBlogSlug: string, entry: unknown) {
    this.server.to(liveBlogSlug).emit("new-entry", entry);
  }
}

@Controller("live-blog")
class LiveBlogController {
  constructor(private liveBlogService: LiveBlogService, private gateway: LiveBlogGateway) {}

  @Get(":slug")
  findOne(@Param("slug") slug: string) {
    return this.liveBlogService.findBySlug(slug);
  }

  @UseGuards(FirebaseAuthGuard, RolesGuard)
  @Roles(Role.SUPER_ADMIN, Role.EDITOR_IN_CHIEF, Role.EDITOR, Role.JOURNALIST)
  @Post(":liveBlogId/entries")
  async addEntry(@Param("liveBlogId") liveBlogId: string, @Body() dto: CreateEntryDto) {
    const entry = await this.liveBlogService.addEntry(liveBlogId, dto);
    this.gateway.broadcastNewEntry(liveBlogId, entry);
    return entry;
  }
}

@Module({
  imports: [AuthModule],
  providers: [LiveBlogService, LiveBlogGateway],
  controllers: [LiveBlogController],
})
export class LiveBlogModule {}
