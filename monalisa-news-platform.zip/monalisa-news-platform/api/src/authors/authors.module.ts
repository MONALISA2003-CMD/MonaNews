import { Injectable, NotFoundException, Module, Controller, Get, Param, Query } from "@nestjs/common";
import { Role, ArticleStatus } from "@prisma/client";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
class AuthorsService {
  constructor(private prisma: PrismaService) {}

  async findBySlug(idOrSlug: string) {
    // Users don't have a dedicated slug field in the schema — in production
    // add a unique `slug` column to User (or a lightweight AuthorProfile
    // view) rather than looking up by id here.
    const author = await this.prisma.user.findFirst({
      where: { id: idOrSlug, role: { in: [Role.JOURNALIST, Role.EDITOR, Role.EDITOR_IN_CHIEF] } },
    });
    if (!author) throw new NotFoundException(`Author "${idOrSlug}" not found.`);
    // firebaseUid is an internal identifier, not something a public author
    // profile page needs to expose.
    const { firebaseUid: _firebaseUid, ...safeAuthor } = author;
    return safeAuthor;
  }

  findArticlesByAuthor(authorId: string, skip = 0, take = 20) {
    return this.prisma.article.findMany({
      where: { authorId, status: ArticleStatus.PUBLISHED },
      orderBy: { publishedAt: "desc" },
      skip,
      take,
      include: { category: true },
    });
  }
}

@Controller("authors")
class AuthorsController {
  constructor(private authorsService: AuthorsService) {}

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.authorsService.findBySlug(id);
  }

  @Get(":id/articles")
  findArticles(@Param("id") id: string, @Query("skip") skip?: string, @Query("take") take?: string) {
    return this.authorsService.findArticlesByAuthor(id, skip ? Number(skip) : undefined, take ? Number(take) : undefined);
  }
}

@Module({
  providers: [AuthorsService],
  controllers: [AuthorsController],
})
export class AuthorsModule {}
