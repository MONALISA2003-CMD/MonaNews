import {
  Injectable,
  NotFoundException,
  Module,
  Controller,
  Get,
  Post,
  Patch,
  Param,
  Body,
  UseGuards,
} from "@nestjs/common";
import { IsString, MinLength, MaxLength, IsBoolean } from "class-validator";
import { Role } from "@prisma/client";
import { PrismaService } from "../prisma/prisma.service";
import { FirebaseAuthGuard } from "../auth/guards/firebase-auth.guard";
import { RolesGuard } from "../auth/guards/roles.guard";
import { Roles } from "../auth/decorators/roles.decorator";
import { CurrentUser } from "../auth/decorators/current-user.decorator";
import { AuthModule } from "../auth/auth.module";

class CreateCommentDto {
  @IsString()
  @MinLength(1)
  @MaxLength(2000)
  body!: string;
}

class ModerateCommentDto {
  @IsBoolean()
  approved!: boolean;
}

@Injectable()
class CommentsService {
  constructor(private prisma: PrismaService) {}

  // Public — only ever returns approved comments. Unmoderated comments
  // stay invisible until a MODERATOR/EDITOR approves them (see moderate()
  // below). Pairs well with the moderateComment Gemini function in
  // monalisa-news-firebase for a first-pass filter before human review —
  // that's not wired to auto-call this endpoint yet, left as a manual step.
  async findForArticle(articleId: string) {
    return this.prisma.comment.findMany({
      where: { articleId, approved: true },
      orderBy: { createdAt: "desc" },
      include: { author: { select: { id: true, name: true, avatarUrl: true } } },
    });
  }

  async create(articleId: string, authorId: string, dto: CreateCommentDto) {
    const article = await this.prisma.article.findUnique({ where: { id: articleId } });
    if (!article) throw new NotFoundException(`Article "${articleId}" not found.`);

    return this.prisma.comment.create({
      data: { articleId, authorId, body: dto.body, approved: false },
      include: { author: { select: { id: true, name: true, avatarUrl: true } } },
    });
  }

  async moderate(commentId: string, dto: ModerateCommentDto) {
    const comment = await this.prisma.comment.findUnique({ where: { id: commentId } });
    if (!comment) throw new NotFoundException(`Comment "${commentId}" not found.`);
    return this.prisma.comment.update({ where: { id: commentId }, data: { approved: dto.approved } });
  }

  // For the moderation queue in a future admin screen — anything awaiting review.
  findPending() {
    return this.prisma.comment.findMany({
      where: { approved: false },
      orderBy: { createdAt: "asc" },
      include: { author: { select: { id: true, name: true } }, article: { select: { id: true, headline: true, slug: true } } },
    });
  }
}

@Controller()
class CommentsController {
  constructor(private commentsService: CommentsService) {}

  @Get("articles/:articleId/comments")
  findForArticle(@Param("articleId") articleId: string) {
    return this.commentsService.findForArticle(articleId);
  }

  @UseGuards(FirebaseAuthGuard)
  @Post("articles/:articleId/comments")
  create(@Param("articleId") articleId: string, @CurrentUser() user: { id: string }, @Body() dto: CreateCommentDto) {
    return this.commentsService.create(articleId, user.id, dto);
  }

  @UseGuards(FirebaseAuthGuard, RolesGuard)
  @Roles(Role.SUPER_ADMIN, Role.EDITOR_IN_CHIEF, Role.EDITOR, Role.MODERATOR)
  @Get("comments/pending")
  findPending() {
    return this.commentsService.findPending();
  }

  @UseGuards(FirebaseAuthGuard, RolesGuard)
  @Roles(Role.SUPER_ADMIN, Role.EDITOR_IN_CHIEF, Role.EDITOR, Role.MODERATOR)
  @Patch("comments/:id/moderate")
  moderate(@Param("id") id: string, @Body() dto: ModerateCommentDto) {
    return this.commentsService.moderate(id, dto);
  }
}

@Module({
  imports: [AuthModule],
  providers: [CommentsService],
  controllers: [CommentsController],
})
export class CommentsModule {}
