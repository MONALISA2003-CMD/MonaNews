import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { ThrottlerModule, ThrottlerGuard } from "@nestjs/throttler";
import { APP_GUARD } from "@nestjs/core";
import { PrismaModule } from "./prisma/prisma.module";
import { AuthModule } from "./auth/auth.module";
import { ArticlesModule } from "./articles/articles.module";
import { CategoriesModule } from "./categories/categories.module";
import { AuthorsModule } from "./authors/authors.module";
import { SearchModule } from "./search/search.module";
import { MarketsModule } from "./markets/markets.module";
import { NewslettersModule } from "./newsletters/newsletters.module";
import { LiveBlogModule } from "./live-blog/live-blog.module";
import { CommentsModule } from "./comments/comments.module";
import { SavedArticlesModule } from "./saved-articles/saved-articles.module";
import { UsersModule } from "./users/users.module";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot({ throttlers: [{ ttl: 60_000, limit: 100 }] }), // global rate limit
    PrismaModule,
    AuthModule,
    ArticlesModule,
    CategoriesModule,
    AuthorsModule,
    SearchModule,
    MarketsModule,
    NewslettersModule,
    LiveBlogModule,
    CommentsModule,
    SavedArticlesModule,
    UsersModule,
  ],
  providers: [{ provide: APP_GUARD, useClass: ThrottlerGuard }],
})
export class AppModule {}
