import { Injectable, NotFoundException, Module, Controller, Get, Param } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
class CategoriesService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.category.findMany({ include: { subtags: true } });
  }

  async findBySlug(slug: string) {
    const category = await this.prisma.category.findUnique({
      where: { slug },
      include: { subtags: true },
    });
    if (!category) throw new NotFoundException(`Category "${slug}" not found.`);
    return category;
  }
}

@Controller("categories")
class CategoriesController {
  constructor(private categoriesService: CategoriesService) {}

  // Public — powers the "All Sections" directory and every category nav link.
  @Get()
  findAll() {
    return this.categoriesService.findAll();
  }

  @Get(":slug")
  findOne(@Param("slug") slug: string) {
    return this.categoriesService.findBySlug(slug);
  }
}

@Module({
  providers: [CategoriesService],
  controllers: [CategoriesController],
  exports: [CategoriesService],
})
export class CategoriesModule {}
