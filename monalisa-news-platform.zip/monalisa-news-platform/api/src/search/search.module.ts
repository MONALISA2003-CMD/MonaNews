import { Injectable, Module, Controller, Get, Query } from "@nestjs/common";
import { ArticleStatus } from "@prisma/client";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
class SearchService {
  constructor(private prisma: PrismaService) {}

  // NOTE: this uses Postgres `contains` filtering, which is fine at small
  // scale but won't give you fuzzy matching, relevance ranking, or
  // autocomplete. The brief calls for semantic/instant/fuzzy search —
  // swap this method for an Elasticsearch or OpenSearch client (or
  // pgvector similarity search for the "AI Search" feature) when ready.
  async search(query: string, take = 20) {
    if (!query?.trim()) return [];
    return this.prisma.article.findMany({
      where: {
        status: ArticleStatus.PUBLISHED,
        OR: [
          { headline: { contains: query, mode: "insensitive" } },
          { dek: { contains: query, mode: "insensitive" } },
          { body: { contains: query, mode: "insensitive" } },
        ],
      },
      take,
      include: { category: true, author: true },
    });
  }
}

@Controller("search")
class SearchController {
  constructor(private searchService: SearchService) {}

  @Get()
  search(@Query("q") q: string, @Query("take") take?: string) {
    return this.searchService.search(q, take ? Number(take) : undefined);
  }
}

@Module({
  providers: [SearchService],
  controllers: [SearchController],
})
export class SearchModule {}
