import { Injectable, Module, Controller, Get, Post, Delete, Param, UseGuards } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { FirebaseAuthGuard } from "../auth/guards/firebase-auth.guard";
import { CurrentUser } from "../auth/decorators/current-user.decorator";
import { AuthModule } from "../auth/auth.module";

@Injectable()
class SavedArticlesService {
  constructor(private prisma: PrismaService) {}

  findAllForUser(userId: string) {
    return this.prisma.savedArticle.findMany({
      where: { userId },
      orderBy: { savedAt: "desc" },
      include: { article: { include: { category: true } } },
    });
  }

  save(userId: string, articleId: string) {
    // Upsert instead of create — saving something already saved should be
    // a harmless no-op, not a 409 the front-end has to handle specially.
    return this.prisma.savedArticle.upsert({
      where: { userId_articleId: { userId, articleId } },
      update: {},
      create: { userId, articleId },
    });
  }

  async unsave(userId: string, articleId: string) {
    await this.prisma.savedArticle.deleteMany({ where: { userId, articleId } });
    return { removed: true };
  }
}

@Controller()
class SavedArticlesController {
  constructor(private savedArticlesService: SavedArticlesService) {}

  @UseGuards(FirebaseAuthGuard)
  @Get("me/saved-articles")
  findAll(@CurrentUser() user: { id: string }) {
    return this.savedArticlesService.findAllForUser(user.id);
  }

  @UseGuards(FirebaseAuthGuard)
  @Post("articles/:articleId/save")
  save(@Param("articleId") articleId: string, @CurrentUser() user: { id: string }) {
    return this.savedArticlesService.save(user.id, articleId);
  }

  @UseGuards(FirebaseAuthGuard)
  @Delete("articles/:articleId/save")
  unsave(@Param("articleId") articleId: string, @CurrentUser() user: { id: string }) {
    return this.savedArticlesService.unsave(user.id, articleId);
  }
}

@Module({
  imports: [AuthModule],
  providers: [SavedArticlesService],
  controllers: [SavedArticlesController],
})
export class SavedArticlesModule {}
