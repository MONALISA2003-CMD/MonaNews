import { Injectable, Module, Controller, Get } from "@nestjs/common";

// No MarketDataPoint model exists yet in schema.prisma because prices are
// high-frequency, time-series data that doesn't belong in the primary
// Postgres database — it should live in Redis (latest snapshot, for fast
// reads) with periodic writes to a time-series store if history matters.
// This service is a placeholder for that integration.
@Injectable()
class MarketsService {
  getSnapshot() {
    return {
      updatedAt: new Date().toISOString(),
      stocks: [
        { symbol: "UMEME", price: 312.0, change: 1.4 },
        { symbol: "SBU", price: 42.5, change: -0.6 },
      ],
      currencies: [{ pair: "USD/UGX", rate: 3689.0, change: 0.21 }],
      commodities: [{ name: "Gold (per oz)", price: 2295.4, change: 0.72 }],
      crypto: [{ symbol: "BTC", price: 61240, change: 2.1 }],
      _source: "MOCK — replace with a real market data provider + Redis cache",
    };
  }
}

@Controller("markets")
class MarketsController {
  constructor(private marketsService: MarketsService) {}

  @Get("snapshot")
  getSnapshot() {
    return this.marketsService.getSnapshot();
  }
}

@Module({
  providers: [MarketsService],
  controllers: [MarketsController],
})
export class MarketsModule {}
