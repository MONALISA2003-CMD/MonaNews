# Monalisa News API

A NestJS 10 + Prisma REST API backing the Monalisa News front-end
(`monalisa-news-nextjs`). Same disclaimer as the front-end package: **this
was written in a sandbox with no network access, so it has not been
installed or run.** It's correct, idiomatic NestJS/Prisma as far as careful
manual review can confirm, but your first `npm install` is its first real
compile.

## Getting started

```bash
npm install
cp .env.example .env          # set a real DATABASE_URL and Firebase Admin credentials
npx prisma migrate dev --name init
npx prisma db seed             # loads the 25 categories + 5 newsletters + 1 sample editor
npm run start:dev              # http://localhost:4000/api/v1
```

## What's here

- **`prisma/schema.prisma`** — identical to the schema shipped with the
  Next.js package. In a real monorepo this would be a single shared
  package (e.g. `packages/db`) instead of two copies — ask if you'd like
  that restructured into a monorepo layout (npm/pnpm workspaces).
- **Auth** (`src/auth`) — no longer issues its own tokens. Firebase Auth
  (shared with `monalisa-news-firebase` and the web app) is the single
  identity provider; this API just verifies the Firebase ID token on each
  request (`FirebaseAuthGuard`) and auto-provisions a matching `User` row
  on first sight (`AuthService.findOrProvisionUser`). New accounts default
  to `SUBSCRIBER` — promote someone to `JOURNALIST`/`EDITOR`/etc. with a
  direct DB update for now (see `prisma/seed.ts`'s comment; an admin
  "manage users" screen isn't built yet). `RolesGuard` enforces the eleven
  roles from the brief on top of that.
- **Articles** (`src/articles`) — public read endpoints for the site, and
  role-gated create/update/archive endpoints for the newsroom. Every update
  writes an `ArticleRevision` snapshot first, which is what the CMS's
  "Revision History" feature reads from.
- **Categories, Authors** — public read endpoints.
- **Search** (`src/search`) — works today via Postgres `ILIKE` filtering.
  This is a placeholder: the brief calls for semantic/fuzzy/instant search,
  which means Elasticsearch, OpenSearch, or pgvector for the "AI Search"
  feature. The method is isolated so swapping the implementation doesn't
  touch the controller.
- **Markets** (`src/markets`) — returns a static snapshot. Real prices are
  high-frequency data that belongs in Redis, not Postgres — see the comment
  in `markets.module.ts`.
- **Newsletters** — list + authenticated subscribe endpoint.
- **Live Blog** (`src/live-blog`) — REST endpoint to fetch entries, plus a
  Socket.IO gateway (`@nestjs/websockets`) that pushes new entries to
  connected clients in real time, matching the brief's WebSocket
  requirement instead of making the front-end poll.

## Still needed for production

- Real database (`DATABASE_URL`) and running `prisma migrate dev`
- A real search backend (see above)
- Redis for market data, sessions, and BullMQ job queues (content
  moderation, AI processing, email sending — all mentioned in the brief
  but not built here)
- The actual AI integrations (OpenAI/Claude/Gemini clients + RAG) —
  nothing here calls a model; the front-end's admin editor has UI buttons
  for this that aren't wired up yet
- Deployment: containerize with Docker, put behind Cloudflare per the
  brief — no `Dockerfile` included yet, ask if useful
