import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// Mirrors src/data/categories.ts on the Next.js side (25 sections from the brief).
// In a monorepo this list would be defined once and shared by both apps.
const CATEGORY_SEEDS = [
  { slug: "breakingnews", title: "Breaking News", description: "The latest confirmed developments, updated as they happen.", color: "bg-red" },
  { slug: "politics", title: "Politics", description: "Government, elections, and policy from the newsroom's political desk.", color: "bg-navy" },
  { slug: "business", title: "Business", description: "Markets, trade, and the companies shaping the regional economy.", color: "bg-red" },
  { slug: "technology", title: "Technology", description: "Product launches, regulation, and the companies building what's next.", color: "bg-blue" },
  { slug: "ai", title: "Artificial Intelligence", description: "How AI is reshaping work, policy, and daily life.", color: "bg-purple" },
  { slug: "cybersecurity", title: "Cybersecurity", description: "Threats, breaches, and how institutions are defending against them.", color: "bg-teal" },
  { slug: "science", title: "Science", description: "Discovery, space, and research from labs across the region and beyond.", color: "bg-green" },
  { slug: "health", title: "Health", description: "Public health, medicine, and the policies shaping care.", color: "bg-red" },
  { slug: "sports", title: "Sports", description: "Scores, transfers, and the stories behind the games.", color: "bg-green" },
  { slug: "entertainment", title: "Entertainment", description: "Film, music, and culture from stages and screens across the region.", color: "bg-orange" },
  { slug: "africa", title: "Africa", description: "Economy, politics, and culture from across the continent.", color: "bg-navy" },
  { slug: "world", title: "World", description: "International news, diplomacy, and global affairs.", color: "bg-blue" },
  { slug: "climate", title: "Climate & Environment", description: "Warming, weather, and the policies aimed at both.", color: "bg-green" },
  { slug: "opinion", title: "Opinion & Editorial", description: "Columns, guest essays, and the editorial board's take.", color: "bg-navy" },
  { slug: "investigations", title: "Investigations", description: "Accountability reporting from the newsroom's investigative unit.", color: "bg-red" },
  { slug: "explainers", title: "Explainers", description: "Plain-language breakdowns of complex stories.", color: "bg-teal" },
  { slug: "factcheck", title: "Fact Check", description: "Verifying viral claims against the record.", color: "bg-red" },
  { slug: "videos", title: "Videos", description: "Reporting, explainers, and live coverage on video.", color: "bg-navy" },
  { slug: "podcasts", title: "Podcasts", description: "Weekly conversations and deep dives from the newsroom.", color: "bg-blue" },
  { slug: "editorial", title: "Editorial", description: "The official position of the Monalisa News editorial board.", color: "bg-navy" },
  { slug: "environment", title: "Environment", description: "Conservation, biodiversity, and the natural world.", color: "bg-green" },
  { slug: "photostories", title: "Photo Stories", description: "The week's news, told in pictures.", color: "bg-navy" },
  { slug: "communityvoices", title: "Community Voices", description: "Guest essays from readers and local contributors.", color: "bg-blue" },
  { slug: "weekendreads", title: "Weekend Reads", description: "Longer stories for slower days.", color: "bg-red" },
  { slug: "morningbrief", title: "Morning Brief", description: "The five stories to know, every weekday morning.", color: "bg-navy" },
];

const NEWSLETTER_SEEDS = [
  { slug: "morning-brief", name: "Morning Brief", cadence: "Daily", description: "The five stories to know, every weekday before 7 AM." },
  { slug: "weekend-reads", name: "Weekend Reads", cadence: "Weekly", description: "Longer stories for slower days, every Saturday." },
  { slug: "politics-weekly", name: "Politics Weekly", cadence: "Weekly", description: "A Friday digest of the week's biggest political stories." },
  { slug: "markets-daily", name: "Markets Daily", cadence: "Daily", description: "Prices, moves, and context before the opening bell." },
  { slug: "breaking-alerts", name: "Breaking News Alerts", cadence: "Instant", description: "Confirmed major developments, sent the moment they're verified." },
];

async function main() {
  for (const cat of CATEGORY_SEEDS) {
    await prisma.category.upsert({ where: { slug: cat.slug }, update: {}, create: cat });
  }

  for (const nl of NEWSLETTER_SEEDS) {
    await prisma.newsletter.upsert({ where: { slug: nl.slug }, update: {}, create: nl });
  }

  // No sample user is seeded here — every User row now needs a real
  // firebaseUid, which only exists once someone actually signs in through
  // Firebase Auth (they're auto-provisioned on first /auth/me call — see
  // AuthService.findOrProvisionUser). To make your own account an editor:
  //   1. Sign in once through the site so your User row gets created
  //   2. UPDATE "User" SET role = 'EDITOR' WHERE email = 'you@example.com';
  // (An admin "manage users" screen to do this from the CMS isn't built yet.)

  // Matches the slug web/src/app/live-blog/page.tsx requests, and mirrors
  // the mock content that page falls back to if the API is unreachable.
  const liveBlog = await prisma.liveBlog.upsert({
    where: { slug: "climate-summit-closing" },
    update: {},
    create: {
      slug: "climate-summit-closing",
      title: "Climate Summit Closing Day: Live Updates as Negotiators Finalize the Framework",
      summary: "Rolling coverage from Nairobi as delegations move toward a final agreement.",
      isLive: true,
    },
  });

  const existingEntries = await prisma.liveBlogEntry.count({ where: { liveBlogId: liveBlog.id } });
  if (existingEntries === 0) {
    await prisma.liveBlogEntry.createMany({
      data: [
        {
          liveBlogId: liveBlog.id,
          tag: "Blog Start",
          title: "Welcome to our live coverage of the summit's closing day",
          body: "Our World Desk team is on the ground in Nairobi as negotiators aim to finalize the draft carbon-pricing framework before delegations depart this evening.",
        },
        {
          liveBlogId: liveBlog.id,
          title: "Coastal-infrastructure fund reportedly set at an initial $2.4B",
          body: "Two delegation officials separately described the figure as a starting commitment, with additional pledges expected over the coming year.",
        },
        {
          liveBlogId: liveBlog.id,
          title: "Closing plenary pushed back by 90 minutes",
          body: "Organizers say the delay is procedural, giving legal teams more time to finalize the framework's text.",
        },
        {
          liveBlogId: liveBlog.id,
          tag: "Just In",
          title: "Draft framework formally signed by 38 of 42 delegations",
          body: "Officials confirmed the signing moments ago in the main plenary hall.",
        },
      ],
    });
  }

  console.log(`Seeded ${CATEGORY_SEEDS.length} categories, ${NEWSLETTER_SEEDS.length} newsletters, 1 live blog.`);

  // Byline placeholder users + articles matching web/src/data/articles.ts
  // 1:1 by slug — this is what lets Comments and the /articles/:slug
  // endpoint actually return something real instead of 404ing for the
  // articles the front-end already renders in full.
  //
  // IMPORTANT: these firebaseUid values are deterministic placeholders,
  // not real Firebase accounts — nobody can sign in as these authors.
  // They exist only so Article.authorId has something valid to point at.
  // A real deployment should link these rows to actual staff members'
  // real Firebase UIDs once those people sign in (see the User-promotion
  // note above) rather than keep the placeholders.
  const BYLINE_SEEDS = [
    { slug: "aisha-namboga", name: "Aisha Namboga", beat: "Diplomacy & Climate Policy", basedIn: "Nairobi / Kampala" },
    { slug: "john-mulusimbi", name: "John Mulusimbi", beat: "Politics & Policy", basedIn: "Kampala" },
    { slug: "diana-nakate", name: "Diana Nakate", beat: "Business & Trade", basedIn: "Kampala" },
    { slug: "brian-tumwesigye", name: "Brian Tumwesigye", beat: "Technology & AI", basedIn: "Kampala" },
    { slug: "denis-muwanga", name: "Denis Muwanga", beat: "Sports", basedIn: "Kampala" },
  ];

  const bylineUsers: Record<string, { id: string }> = {};
  for (const b of BYLINE_SEEDS) {
    const user = await prisma.user.upsert({
      where: { firebaseUid: `seed-${b.slug}` },
      update: {},
      create: {
        firebaseUid: `seed-${b.slug}`,
        name: b.name,
        email: `${b.slug}@monalisanews.local`,
        role: "JOURNALIST",
        beat: b.beat,
        basedIn: b.basedIn,
      },
    });
    bylineUsers[b.slug] = user;
  }

  const ARTICLE_SEEDS = [
    {
      slug: "climate-summit",
      headline: "Global Leaders Unite At Climate Summit To Tackle Rising Environmental Threats",
      dek: "World leaders have gathered in Nairobi for a historic climate summit aimed at accelerating global action on climate change and sustainable development.",
      categorySlug: "climate",
      authorSlug: "aisha-namboga",
      readingTimeMin: 5,
    },
    {
      slug: "coalition-talks-cabinet-seats",
      headline: "Coalition talks enter final stretch as smaller parties press for cabinet seats",
      dek: "With days left before the formal deadline, negotiations between the leading coalition partners and three smaller parties have intensified.",
      categorySlug: "politics",
      authorSlug: "john-mulusimbi",
      readingTimeMin: 4,
    },
    {
      slug: "uganda-exports-record",
      headline: "Uganda's exports reach record $6.2B in 2026",
      dek: "Coffee, gold, and fish exports lead the growth in the first half of the year, according to new trade data released this week.",
      categorySlug: "business",
      authorSlug: "diana-nakate",
      readingTimeMin: 3,
    },
    {
      slug: "ai-transform-jobs-education-healthcare",
      headline: "AI will transform jobs, education, and healthcare, experts say",
      dek: "A new sector-by-sector review argues AI adoption is moving faster in service delivery than manufacturing.",
      categorySlug: "ai",
      authorSlug: "brian-tumwesigye",
      readingTimeMin: 5,
    },
    {
      slug: "uganda-cranes-afcon-2027",
      headline: "Uganda Cranes qualify for AFCON 2027",
      dek: "The Cranes secure a strong win against South Sudan in the final qualifier, sealing their spot in next year's tournament.",
      categorySlug: "sports",
      authorSlug: "denis-muwanga",
      readingTimeMin: 3,
    },
  ];

  for (const a of ARTICLE_SEEDS) {
    const category = await prisma.category.findUnique({ where: { slug: a.categorySlug } });
    if (!category) continue; // shouldn't happen — categories are seeded above
    await prisma.article.upsert({
      where: { slug: a.slug },
      update: {},
      create: {
        slug: a.slug,
        headline: a.headline,
        dek: a.dek,
        // Full body text lives in web/src/data/articles.ts for now — this
        // seeds a short placeholder so the row exists for Comments/save
        // to attach to. Keeping full editorial content in two places
        // would drift; see api/README.md's monorepo note.
        body: a.dek,
        status: "PUBLISHED",
        publishedAt: new Date(),
        readingTimeMin: a.readingTimeMin,
        category: { connect: { id: category.id } },
        author: { connect: { id: bylineUsers[a.authorSlug].id } },
      },
    });
  }

  console.log(`Seeded ${BYLINE_SEEDS.length} byline users and ${ARTICLE_SEEDS.length} articles.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
