# Monalisa News — AI Functions (Firebase + Gemini)

The AI-powered features from the brief (summaries, tag suggestions,
headline suggestions, sentiment, fact-check triage, comment moderation,
alt text, and a grounded chat assistant) as Firebase Cloud Functions
(Gen 2) calling the Gemini API. Same standing disclaimer: written with no
network access, so `firebase deploy` has not actually been run — this is
your first real test.

## Why Firebase Functions here

- **Free tier fits this use case.** Cloud Functions Gen 2 has a real free
  tier (2M invocations/month as of writing), and Gemini 1.5 Flash — which
  every function here uses — has its own free-tier request allowance
  through Google AI Studio. For a newsroom's AI-assist buttons (called by
  staff, not on every page load), this comfortably covers normal usage
  without a credit card commitment.
- **No server to run.** Unlike the NestJS API, these are on-demand — you
  don't pay for idle time, and there's nothing to keep alive.
- **Callable functions handle auth + CORS for you.** `onCall` (used
  throughout `functions/src/index.ts`) automatically verifies a Firebase
  Auth ID token and handles CORS, so the client code is just
  `httpsCallable(functions, "generateSummary")(data)`.

## Setup

1. **Get a free Gemini API key**: https://aistudio.google.com/app/apikey
2. **Create a Firebase project** (or reuse one): https://console.firebase.google.com
3. Install the CLI and log in:
   ```bash
   npm install -g firebase-tools
   firebase login
   ```
4. Set your project ID in `.firebaserc` (replace
   `REPLACE_WITH_YOUR_FIREBASE_PROJECT_ID`).
5. Install function dependencies and set the Gemini key as a secret
   (never commit it — this stores it in Google Secret Manager, not in code):
   ```bash
   cd functions
   npm install
   firebase functions:secrets:set GEMINI_API_KEY
   ```
6. Test locally with the emulator before deploying:
   ```bash
   npm run serve
   ```
7. Deploy for real:
   ```bash
   npm run deploy
   ```

## Functions included

| Function | Brief feature | Requires sign-in? |
|---|---|---|
| `generateSummary` | AI Summaries, Key Takeaways | Yes |
| `suggestTags` | Automatic Tags / Keywords | Yes |
| `suggestHeadlines` | AI Headline Suggestions | Yes |
| `analyzeSentiment` | Sentiment Analysis | Yes |
| `factCheckAssist` | AI Fact-Check Assistant | Yes |
| `moderateComment` | Content Moderation | No — runs on public comment submission |
| `generateAltText` | Image Caption / Alt Text Generator | Yes |
| `chatAssistant` | AI News Assistant / Chat Assistant | No |

"Requires sign-in" means the function throws `unauthenticated` unless the
caller has a Firebase Auth session — appropriate for newsroom-only tools.
`moderateComment` and `chatAssistant` are reader-facing, so they don't
require auth, but **should** be protected with
[Firebase App Check](https://firebase.google.com/docs/app-check) before
going live, so only your actual site (not a scraped API key) can call
them. That's not wired up here — it's a config toggle in the Firebase
console plus one SDK call on the client, worth doing before launch.

## Important honesty notes baked into the code

- **`factCheckAssist` does not verify claims.** Gemini has no live web
  access in this call, so the function is written to only flag vague or
  unsourced claims for a *human* fact-checker — it deliberately never
  returns "true" or "false". The brief itself requires fact-checks to
  reference real published sources, which means this needs Google Search
  grounding (Vertex AI's grounding feature) or a human in the loop before
  it's trustworthy. Don't remove that guardrail to make the UI feel more
  "finished" — a fact-checker that confidently guesses is worse than none.
- **`chatAssistant` only answers from context you pass it** (published
  article excerpts from `monalisa-news-api`'s `/search` endpoint). If you
  don't pass any, it says so rather than falling back to Gemini's general
  knowledge — that's what keeps it "trained only on published Monalisa
  News articles" as the brief specifies, instead of quietly becoming a
  generic chatbot.
- **`generateAltText` takes a text description, not the actual image.**
  Gemini 1.5 Flash supports image input (multimodal), so the real upgrade
  is passing the image itself instead of a human-written description —
  left as text-only here to keep the first version simple and cheap.

## Connecting from the Next.js app

See `monalisa-news-nextjs/src/lib/firebase.ts` and the AI Assist buttons
in `monalisa-news-nextjs/src/app/admin/articles/new/page.tsx` — those call
these functions directly via the Firebase client SDK once you set the
`NEXT_PUBLIC_FIREBASE_*` environment variables (from your Firebase
project's web app config) in `monalisa-news-nextjs/.env.local`.
