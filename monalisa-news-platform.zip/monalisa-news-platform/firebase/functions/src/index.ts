import { onCall, HttpsError } from "firebase-functions/v2/https";
import { setGlobalOptions } from "firebase-functions/v2";
import { generateJson, getGeminiModel, geminiApiKey } from "./gemini";

// Keep cold starts and cost predictable — these are short, cheap calls.
setGlobalOptions({ region: "us-central1", maxInstances: 10, timeoutSeconds: 30 });

const MAX_BODY_CHARS = 20_000; // guards against runaway token usage / cost

function requireAuth(auth: unknown) {
  if (!auth) {
    throw new HttpsError("unauthenticated", "Sign in required to use newsroom AI tools.");
  }
}

function requireText(value: unknown, field: string): string {
  if (typeof value !== "string" || !value.trim()) {
    throw new HttpsError("invalid-argument", `"${field}" is required.`);
  }
  return value.slice(0, MAX_BODY_CHARS);
}

// ---------------------------------------------------------------------------
// AI Summaries + Key Takeaways
// Powers the admin editor's "Generate summary" button and the article
// page's `aiSummary` / `aiKeyTakeaways` fields in schema.prisma.
// ---------------------------------------------------------------------------
export const generateSummary = onCall({ secrets: [geminiApiKey] }, async (request) => {
  requireAuth(request.auth);
  const body = requireText(request.data?.body, "body");

  return generateJson<{ summary: string; keyTakeaways: string[] }>(
    `You are a news editor's assistant. Read the article body below and return ONLY valid JSON
     (no markdown fences, no commentary) in this exact shape:
     {"summary": "a neutral 2-3 sentence summary", "keyTakeaways": ["short bullet", "short bullet", "short bullet"]}

     Article body:
     """${body}"""`
  );
});

// ---------------------------------------------------------------------------
// Automatic Tags / Automatic Keywords
// ---------------------------------------------------------------------------
export const suggestTags = onCall({ secrets: [geminiApiKey] }, async (request) => {
  requireAuth(request.auth);
  const body = requireText(request.data?.body, "body");

  return generateJson<{ tags: string[] }>(
    `Suggest 4-6 concise, lowercase, hyphenated tags for this news article.
     Return ONLY valid JSON: {"tags": ["tag-one", "tag-two"]}

     Article body:
     """${body}"""`
  );
});

// ---------------------------------------------------------------------------
// AI Headline Suggestions
// ---------------------------------------------------------------------------
export const suggestHeadlines = onCall({ secrets: [geminiApiKey] }, async (request) => {
  requireAuth(request.auth);
  const body = requireText(request.data?.body, "body");

  return generateJson<{ headlines: string[] }>(
    `Write 3 alternative headlines for this article. Match a serious wire-service tone
     (AP/Reuters style) — no clickbait, no "you won't believe", no exclamation marks.
     Return ONLY valid JSON: {"headlines": ["...", "...", "..."]}

     Article body:
     """${body}"""`
  );
});

// ---------------------------------------------------------------------------
// Sentiment Analysis
// ---------------------------------------------------------------------------
export const analyzeSentiment = onCall({ secrets: [geminiApiKey] }, async (request) => {
  requireAuth(request.auth);
  const body = requireText(request.data?.body, "body");

  return generateJson<{ sentiment: "positive" | "neutral" | "negative"; reasoning: string }>(
    `Classify the overall tone of this news article as "positive", "neutral", or "negative"
     from a reader's perspective (not the AI's opinion on the topic). Return ONLY valid JSON:
     {"sentiment": "neutral", "reasoning": "one sentence explaining why"}

     Article body:
     """${body}"""`
  );
});

// ---------------------------------------------------------------------------
// AI Fact-Check Assistant
// IMPORTANT: Gemini alone has no live web access from this call, so it
// cannot verify a claim against current sources — it can only flag
// internal inconsistencies, vague sourcing, or claims that need a human
// fact-checker's attention. Treat this as triage, not a verdict, and
// always keep a human fact-checker in the loop (per the brief's own
// requirement that fact-checks "must reference reliable published sources").
export const factCheckAssist = onCall({ secrets: [geminiApiKey] }, async (request) => {
  requireAuth(request.auth);
  const claim = requireText(request.data?.claim, "claim");

  return generateJson<{
    flags: string[];
    needsHumanReview: boolean;
    reasoning: string;
  }>(
    `You are helping a human fact-checker triage a claim before they verify it against real sources.
     You do NOT have live web access, so you must NOT assert whether the claim is true or false.
     Instead: flag anything vague, unsourced, an absolute ("always"/"never"), a statistic without
     attribution, or an extraordinary claim that would need strong sourcing.
     Return ONLY valid JSON:
     {"flags": ["short flag", "short flag"], "needsHumanReview": true, "reasoning": "one sentence"}

     Claim:
     """${claim}"""`
  );
});

// ---------------------------------------------------------------------------
// Content Moderation (comments)
// ---------------------------------------------------------------------------
export const moderateComment = onCall({ secrets: [geminiApiKey] }, async (request) => {
  const text = requireText(request.data?.text, "text");
  // No requireAuth() here — this runs automatically when any reader submits
  // a comment, not just newsroom staff. Gate it with Firebase App Check in
  // production instead (see README) to stop direct API abuse.

  return generateJson<{ approve: boolean; reason: string }>(
    `Moderate this reader comment on a news article. Reject only for harassment, hate speech,
     explicit content, spam, or clear misinformation presented as fact. Do not reject comments
     merely for disagreeing with the article or the newsroom.
     Return ONLY valid JSON: {"approve": true, "reason": "one short sentence"}

     Comment:
     """${text}"""`
  );
});

// ---------------------------------------------------------------------------
// Image Caption Generator / Alt Text Generator
// Takes a short human-written description (not the raw image — see README
// for the multimodal upgrade path) and produces publication-ready copy.
// ---------------------------------------------------------------------------
export const generateAltText = onCall({ secrets: [geminiApiKey] }, async (request) => {
  requireAuth(request.auth);
  const description = requireText(request.data?.description, "description");
  const headline = typeof request.data?.headline === "string" ? request.data.headline : "";

  return generateJson<{ altText: string; caption: string }>(
    `Given a rough description of a news photo and the article headline it accompanies,
     write (1) concise, accessible alt text (under 125 characters, factual, no "image of")
     and (2) a one-sentence publication caption.
     Return ONLY valid JSON: {"altText": "...", "caption": "..."}

     Headline: "${headline}"
     Photo description: "${description}"`
  );
});

// ---------------------------------------------------------------------------
// AI News Assistant / AI Chat Assistant
// A lightweight RAG pattern: the caller passes a handful of published
// article snippets (fetched from monalisa-news-api's /search or /articles
// endpoints) as `context`, and Gemini answers using only those. This keeps
// the assistant "trained only on published Monalisa News articles" per the
// brief, without needing a vector database for a first version.
// ---------------------------------------------------------------------------
export const chatAssistant = onCall({ secrets: [geminiApiKey] }, async (request) => {
  const question = requireText(request.data?.question, "question");
  const context = Array.isArray(request.data?.context) ? request.data.context : [];

  if (context.length === 0) {
    return {
      answer:
        "I can only answer using published Monalisa News articles, and none were provided for this question. Try rephrasing, or ask about a topic we've covered recently.",
      grounded: false,
    };
  }

  const contextBlock = context
    .slice(0, 8)
    .map((c: unknown, i: number) => `[${i + 1}] ${String(c).slice(0, 1500)}`)
    .join("\n\n");

  const model = getGeminiModel();
  const result = await model.generateContent(
    `You are the Monalisa News reader assistant. Answer the question using ONLY the numbered
     article excerpts below. If they don't contain the answer, say so plainly — do not use
     outside knowledge. Cite excerpt numbers like [1] when you use them. Keep the answer under
     120 words.

     Question: ${question}

     Excerpts:
     ${contextBlock}`
  );

  return { answer: result.response.text(), grounded: true };
});
