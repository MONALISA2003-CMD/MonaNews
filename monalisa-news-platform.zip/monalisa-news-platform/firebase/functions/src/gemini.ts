import { GoogleGenerativeAI } from "@google/generative-ai";
import { defineSecret } from "firebase-functions/params";

// Set this once with:
//   firebase functions:secrets:set GEMINI_API_KEY
// Get a free key at https://aistudio.google.com/app/apikey — the free tier
// (as of writing) covers Gemini 1.5 Flash at generous request/day limits,
// which is what these functions use by default.
export const geminiApiKey = defineSecret("GEMINI_API_KEY");

let client: GoogleGenerativeAI | null = null;

export function getGeminiModel(modelName = "gemini-1.5-flash") {
  if (!client) {
    client = new GoogleGenerativeAI(geminiApiKey.value());
  }
  return client.getGenerativeModel({ model: modelName });
}

/**
 * Asks Gemini for JSON and parses it, tolerating the markdown code-fence
 * wrapping Gemini sometimes adds even when told not to.
 */
export async function generateJson<T>(prompt: string): Promise<T> {
  const model = getGeminiModel();
  const result = await model.generateContent(prompt);
  const text = result.response.text();
  const cleaned = text.replace(/```json\s*|```\s*/g, "").trim();
  return JSON.parse(cleaned) as T;
}
