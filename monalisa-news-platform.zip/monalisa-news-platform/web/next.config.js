/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone", // required for the multi-stage Dockerfile
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "picsum.photos" },
    ],
  },
};

module.exports = nextConfig;
