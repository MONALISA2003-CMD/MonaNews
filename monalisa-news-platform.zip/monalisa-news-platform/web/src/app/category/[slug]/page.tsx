import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import Badge from "@/components/Badge";
import StoryCard from "@/components/StoryCard";
import { CATEGORY_LIST, getCategory } from "@/data/categories";
import { resolveCategory } from "@/lib/resolve-category";

// Pre-render every category at build time (SSG) instead of on every request.
export function generateStaticParams() {
  return CATEGORY_LIST.map((cat) => ({ slug: cat.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const cat = getCategory(params.slug); // metadata doesn't need to be network-dependent
  return { title: `${cat.title} — MONALISA NEWS`, description: cat.desc };
}

export default async function CategoryPage({ params }: { params: { slug: string } }) {
  // Tries monalisa-news-api first, transparently falls back to the bundled
  // mock data if it's unreachable — see src/lib/resolve-category.ts.
  const cat = await resolveCategory(params.slug);
  const [featured, ...rest] = cat.stories;

  return (
    <>
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 pt-5">
        <div className="text-xs text-gray-500 mb-2">
          <Link href="/" className="hover:text-red">Home</Link> / <span className="text-gray-700">{cat.title}</span>
        </div>
        <div className="flex items-end justify-between flex-wrap gap-3 border-b-2 border-navy pb-4">
          <div>
            <h1 className="text-3xl sm:text-4xl font-black text-navy">{cat.title}</h1>
            <p className="text-sm text-gray-500 mt-1">{cat.desc}</p>
          </div>
          <button className="text-sm font-semibold border border-blue text-blue px-4 py-2 rounded-md hover:bg-blue hover:text-white transition shrink-0">
            Follow Section
          </button>
        </div>
        <div className="flex gap-6 text-sm overflow-x-auto mt-4">
          <span className="pb-3 border-b-2 border-navy font-bold text-navy whitespace-nowrap">All</span>
          {cat.subtags.map((t) => (
            <Link key={t.slug} href={`/category/${cat.slug}?tag=${t.slug}`} className="pb-3 border-b-2 border-transparent text-gray-500 hover:text-navy whitespace-nowrap">
              {t.label}
            </Link>
          ))}
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8 grid lg:grid-cols-[1fr_320px] gap-8">
        <div>
          {featured && (
            <Link href={`/article/${featured.slug}`} className="group relative block rounded-lg overflow-hidden">
              <div className="relative aspect-[2/1] w-full">
                <Image src={`https://picsum.photos/seed/${featured.seed}/1100/560`} alt="" fill className="object-cover" priority />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
              <Badge color={featured.badge} className="absolute top-4 left-4">
                {featured.label}
              </Badge>
              <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-7 text-white">
                <h2 className="text-2xl sm:text-3xl font-black leading-tight max-w-2xl">{featured.headline}</h2>
                <span className="text-xs text-white/60 block mt-3">{featured.meta}</span>
              </div>
            </Link>
          )}

          <div className="flex items-center justify-between mt-8 mb-4">
            <span className="text-xs text-gray-500">{rest.length} stories</span>
          </div>

          <div className="grid sm:grid-cols-2 gap-5">
            {rest.map((s) => (
              <StoryCard key={s.slug} story={s} href={s.tags.includes("videos") ? "/video-hub" : undefined} />
            ))}
          </div>
        </div>

        <aside className="flex flex-col gap-4">
          <div className="card p-4">
            <h2 className="text-sm font-black tracking-tight mb-3">MOST READ IN {cat.title.toUpperCase()}</h2>
            <ol className="space-y-3">
              {cat.stories.slice(0, 4).map((s, i) => (
                <li key={s.slug} className="flex items-center gap-3">
                  <span className="w-5 h-5 bg-navy text-white text-xs font-bold rounded flex items-center justify-center shrink-0">
                    {i + 1}
                  </span>
                  <span className="text-xs flex-1">{s.headline}</span>
                </li>
              ))}
            </ol>
          </div>
          <div className="bg-navy text-white rounded-lg p-5">
            <h3 className="text-base font-black leading-tight">{cat.title} Digest</h3>
            <p className="text-xs text-white/70 mt-2">The week&apos;s biggest stories from this section, in your inbox.</p>
            <form className="flex gap-2 mt-3">
              <input type="email" required placeholder="Email address" className="flex-1 min-w-0 rounded-md px-3 py-2 text-xs text-ink bg-white" />
              <button className="bg-red text-white text-xs font-semibold px-3 py-2 rounded-md hover:opacity-90 shrink-0">Sign up</button>
            </form>
          </div>
        </aside>
      </div>
    </>
  );
}
