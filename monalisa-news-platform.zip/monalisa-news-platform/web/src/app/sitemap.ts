import type { MetadataRoute } from "next";
import { CATEGORY_LIST } from "@/data/categories";
import { allKnownArticleSlugs } from "@/lib/resolve-article";
import { AUTHORS } from "@/data/authors";

// Next.js serves this at /sitemap.xml automatically — no route file needed
// beyond this one. Previously there was no sitemap at all.
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://example.com";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticPages: MetadataRoute.Sitemap = [
    { url: BASE_URL, changeFrequency: "hourly", priority: 1 },
    { url: `${BASE_URL}/search`, changeFrequency: "daily", priority: 0.3 },
    { url: `${BASE_URL}/markets`, changeFrequency: "hourly", priority: 0.6 },
    { url: `${BASE_URL}/video-hub`, changeFrequency: "daily", priority: 0.5 },
    { url: `${BASE_URL}/live-blog`, changeFrequency: "hourly", priority: 0.6 },
    { url: `${BASE_URL}/sections`, changeFrequency: "weekly", priority: 0.4 },
    { url: `${BASE_URL}/newsletters`, changeFrequency: "monthly", priority: 0.3 },
  ];

  const categoryPages: MetadataRoute.Sitemap = CATEGORY_LIST.map((cat) => ({
    url: `${BASE_URL}/category/${cat.slug}`,
    changeFrequency: "hourly",
    priority: 0.8,
  }));

  const articlePages: MetadataRoute.Sitemap = allKnownArticleSlugs().map((slug) => ({
    url: `${BASE_URL}/article/${slug}`,
    changeFrequency: "weekly",
    priority: 0.7,
  }));

  const authorPages: MetadataRoute.Sitemap = Object.keys(AUTHORS).map((slug) => ({
    url: `${BASE_URL}/author/${slug}`,
    changeFrequency: "weekly",
    priority: 0.4,
  }));

  return [...staticPages, ...categoryPages, ...articlePages, ...authorPages];
}
