"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { login, register } from "@/lib/auth";

export default function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const next = searchParams.get("next") ?? "/";
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (mode === "login") {
        await login(email, password);
      } else {
        await register(name, email, password);
      }
      router.push(next);
      router.refresh();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong. Is the API running? See monalisa-news-api/README.md."
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-sm mx-auto px-4 py-16">
      <h1 className="text-2xl font-black text-navy mb-1">
        {mode === "login" ? "Sign In" : "Create Account"}
      </h1>
      <p className="text-sm text-gray-500 mb-6">
        {mode === "login" ? "Welcome back to Monalisa News." : "Join to save articles and manage newsletters."}
      </p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-3">
        {mode === "register" && (
          <input
            type="text"
            required
            placeholder="Full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border border-line rounded-md px-3 py-2.5 text-sm"
          />
        )}
        <input
          type="email"
          required
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="border border-line rounded-md px-3 py-2.5 text-sm"
        />
        <input
          type="password"
          required
          minLength={8}
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="border border-line rounded-md px-3 py-2.5 text-sm"
        />

        {error && <p className="text-sm text-red">{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="bg-red text-white text-sm font-semibold py-2.5 rounded-md hover:opacity-90 disabled:opacity-50"
        >
          {submitting ? "Please wait…" : mode === "login" ? "Sign In" : "Create Account"}
        </button>
      </form>

      <p className="text-sm text-gray-500 mt-4 text-center">
        {mode === "login" ? (
          <>
            Don&apos;t have an account?{" "}
            <button onClick={() => setMode("register")} className="text-blue font-semibold hover:underline">
              Create one
            </button>
          </>
        ) : (
          <>
            Already have an account?{" "}
            <button onClick={() => setMode("login")} className="text-blue font-semibold hover:underline">
              Sign in
            </button>
          </>
        )}
      </p>
      <Link href="/" className="block text-center text-xs text-gray-400 mt-6 hover:text-red">
        ← Back to homepage
      </Link>
    </div>
  );
}
