import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import Badge from "@/components/Badge";
import { getAuthor, AUTHORS } from "@/data/authors";
import { ARTICLE_LIST } from "@/data/articles";

export function generateStaticParams() {
  return Object.keys(AUTHORS).map((slug) => ({ slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const author = getAuthor(params.slug);
  return { title: `${author.name} — MONALISA NEWS` };
}

export default function AuthorPage({ params }: { params: { slug: string } }) {
  const author = getAuthor(params.slug);
  // Previously this always showed the same climate+world stories
  // regardless of which author's page you were on — now it genuinely
  // filters by authorSlug against the real article data.
  const articles = ARTICLE_LIST.filter((a) => a.authorSlug === author.slug);

  return (
    <>
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 pt-4 text-xs text-gray-500">
        <Link href="/" className="hover:text-red">Home</Link> / <span className="text-gray-700">{author.name}</span>
      </div>

      <div className="bg-gray-bg border-b border-line mt-4">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8 flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <div className="relative w-28 h-28 rounded-full overflow-hidden shrink-0">
            <Image src={`https://picsum.photos/seed/${author.slug}/240/240`} alt="" fill className="object-cover" />
          </div>
          <div className="flex-1">
            <Badge color="bg-blue">{author.beat}</Badge>
            <h1 className="text-3xl font-black mt-2 text-navy">{author.name}</h1>
            <p className="text-sm text-gray-600 mt-2 max-w-2xl leading-relaxed">{author.bio}</p>
            <div className="flex items-center gap-4 mt-4 text-sm">
              <div><span className="font-black text-lg text-navy">{author.articleCount}</span> <span className="text-gray-500">Articles</span></div>
              <div className="w-px h-5 bg-gray-300" />
              <div><span className="text-gray-500">Based in {author.basedIn}</span></div>
            </div>
          </div>
          <button className="bg-red text-white text-sm font-semibold px-5 py-2.5 rounded-md hover:opacity-90 shrink-0">
            Follow Author
          </button>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
        <h2 className="text-lg font-black tracking-tight mb-4">Articles</h2>
        {articles.length === 0 ? (
          <p className="text-sm text-gray-500">No full articles on file for this author yet — see src/data/articles.ts.</p>
        ) : (
          <div className="flex flex-col gap-4">
            {articles.map((a) => (
              <Link key={a.slug} href={`/article/${a.slug}`} className="group card overflow-hidden flex">
                <div className="relative w-40 sm:w-56 aspect-[3/2] shrink-0">
                  <Image src={`https://picsum.photos/seed/${a.heroSeed}/300/200`} alt="" fill className="object-cover" />
                </div>
                <div className="p-4">
                  <Badge color={a.badge}>{a.categoryTitle}</Badge>
                  <h3 className="font-bold leading-snug mt-2 group-hover:text-red transition-colors">{a.headline}</h3>
                  <span className="text-xs text-gray-500 block mt-2">
                    {new Date(a.publishedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })} · {a.readingTimeMin} min read
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
