import { Suspense } from "react";
import SearchContent from "./SearchContent";

export default function SearchPage() {
  // useSearchParams() in SearchContent requires a Suspense boundary
  // per Next.js App Router rules for client components reading the URL.
  return (
    <Suspense fallback={<div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">Loading…</div>}>
      <SearchContent />
    </Suspense>
  );
}
