"use client";

import Link from "next/link";
import Image from "next/image";
import { useState, useMemo, useEffect, useRef } from "react";
import { useSearchParams } from "next/navigation";
import { CATEGORY_LIST } from "@/data/categories";

// Minimal ambient typing for the Web Speech API, which TypeScript's DOM
// lib doesn't include by default (it's non-standard, Chrome/Edge only).
interface SpeechRecognitionResultLike {
  transcript: string;
}
interface SpeechRecognitionEventLike extends Event {
  results: { [index: number]: { [index: number]: SpeechRecognitionResultLike } };
}
interface SpeechRecognitionLike extends EventTarget {
  lang: string;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
}

export default function SearchContent() {
  const params = useSearchParams();
  const initialQuery = params.get("q") ?? "climate summit";
  const [query, setQuery] = useState(initialQuery);
  const [listening, setListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => {
    // Real browser-native voice search (Web Speech API) — no backend, no
    // API key. Chrome/Edge only; other browsers fall back to the mic
    // button not rendering at all rather than showing something broken.
    const w = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const RecognitionCtor = w.SpeechRecognition ?? w.webkitSpeechRecognition;
    if (!RecognitionCtor) return;

    setVoiceSupported(true);
    const recognition = new RecognitionCtor();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setQuery(transcript);
      setListening(false);
    };
    recognition.onerror = () => setListening(false);
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
  }, []);

  const toggleListening = () => {
    if (!recognitionRef.current) return;
    if (listening) {
      recognitionRef.current.stop();
      setListening(false);
    } else {
      recognitionRef.current.start();
      setListening(true);
    }
  };

  // Flatten every story across every category into one searchable index.
  // In production this is an Elasticsearch/OpenSearch or pgvector query
  // (see README "Search" section) instead of an in-memory scan.
  const allStories = useMemo(
    () => CATEGORY_LIST.flatMap((cat) => cat.stories.map((s) => ({ ...s, categorySlug: cat.slug, categoryTitle: cat.title }))),
    []
  );

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return allStories.slice(0, 10);
    return allStories.filter((s) => s.headline.toLowerCase().includes(q) || s.categoryTitle.toLowerCase().includes(q));
  }, [query, allStories]);

  return (
    <>
      <div className="bg-gray-bg border-b border-line">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-center gap-2 max-w-2xl">
            <div className="flex items-center flex-1 border border-line rounded-full px-4 py-2.5 gap-2 bg-white">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search news, topics, people..."
                className="flex-1 outline-none text-sm bg-transparent"
              />
              {voiceSupported && (
                <button
                  onClick={toggleListening}
                  aria-label={listening ? "Stop voice search" : "Search by voice"}
                  title={listening ? "Listening…" : "Search by voice"}
                  className={`shrink-0 w-7 h-7 rounded-full flex items-center justify-center ${listening ? "bg-red text-white animate-pulse" : "hover:bg-gray-bg"}`}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                    <rect x="9" y="3" width="6" height="11" rx="3" stroke={listening ? "white" : "#6B7280"} strokeWidth="1.7" />
                    <path d="M5 11a7 7 0 0014 0M12 18v3" stroke={listening ? "white" : "#6B7280"} strokeWidth="1.7" strokeLinecap="round" />
                  </svg>
                </button>
              )}
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-3">
            Showing results for <span className="font-semibold text-ink">&quot;{query}&quot;</span> — {results.length} results
          </p>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
        <div className="flex flex-col divide-y divide-line">
          {results.map((s) => (
            <Link key={`${s.categorySlug}-${s.slug}`} href={`/article/${s.slug}`} className="group py-5 flex gap-4">
              <div className="relative w-32 sm:w-44 aspect-[3/2] rounded-md shrink-0 overflow-hidden bg-gray-bg">
                <Image src={`https://picsum.photos/seed/${s.seed}/240/160`} alt="" fill className="object-cover" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase text-blue">{s.categoryTitle}</span>
                <h3 className="font-bold text-lg leading-snug mt-1 group-hover:text-red transition-colors">{s.headline}</h3>
                <span className="text-xs text-gray-400 block mt-2">{s.meta}</span>
              </div>
            </Link>
          ))}
          {results.length === 0 && (
            <div className="text-center py-16 text-gray-500">
              <p className="text-lg font-semibold">No results found</p>
              <p className="text-sm mt-1">Try different keywords.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
