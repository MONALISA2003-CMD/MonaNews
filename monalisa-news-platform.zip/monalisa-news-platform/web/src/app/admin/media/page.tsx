import Image from "next/image";

const MEDIA = Array.from({ length: 12 }, (_, i) => ({
  id: `media-${i}`,
  seed: `admin-media-${i}`,
  kind: i % 5 === 0 ? "video" : "image",
}));

export default function MediaLibraryPage() {
  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-black text-navy">Media Library</h1>
          <p className="text-sm text-gray-500 mt-1">Images and video used across published articles.</p>
        </div>
        <button className="bg-red text-white text-sm font-semibold px-4 py-2 rounded-md hover:opacity-90">Upload</button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        {MEDIA.map((m) => (
          <div key={m.id} className="relative aspect-square rounded-md overflow-hidden bg-gray-bg group">
            <Image src={`https://picsum.photos/seed/${m.seed}/300/300`} alt="" fill className="object-cover" />
            {m.kind === "video" && (
              <span className="absolute bottom-1.5 right-1.5 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded">VIDEO</span>
            )}
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors" />
          </div>
        ))}
      </div>
    </div>
  );
}
