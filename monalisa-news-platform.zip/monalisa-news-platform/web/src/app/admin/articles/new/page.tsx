"use client";

import { useState } from "react";
import { CATEGORY_LIST } from "@/data/categories";
import { aiFunctions } from "@/lib/firebase";

export default function ArticleEditorPage() {
  const [status, setStatus] = useState("Draft");
  const [headline, setHeadline] = useState("");
  const [dek, setDek] = useState("");
  const [body, setBody] = useState("");

  const [aiLoading, setAiLoading] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [summary, setSummary] = useState<{ summary: string; keyTakeaways: string[] } | null>(null);
  const [tags, setTags] = useState<string[] | null>(null);
  const [headlineIdeas, setHeadlineIdeas] = useState<string[] | null>(null);
  const [factCheck, setFactCheck] = useState<{ flags: string[]; needsHumanReview: boolean; reasoning: string } | null>(
    null
  );

  const runAi = async (key: string, fn: () => Promise<void>) => {
    if (!body.trim()) {
      setAiError("Write (or paste) the article body first — these tools read from it.");
      return;
    }
    setAiError(null);
    setAiLoading(key);
    try {
      await fn();
    } catch (err) {
      // Most likely cause during local dev: not signed in (use the same
      // /login as the rest of the site), or GEMINI_API_KEY isn't set as a
      // Functions secret yet.
      setAiError(err instanceof Error ? err.message : "AI request failed. Is the Firebase Functions project deployed?");
    } finally {
      setAiLoading(null);
    }
  };

  return (
    <div className="p-8 grid lg:grid-cols-[1fr_320px] gap-6">
      <div>
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-black text-navy">New Article</h1>
          <div className="flex items-center gap-2">
            <button className="border border-line text-sm font-semibold px-4 py-2 rounded-md hover:bg-gray-bg">Save Draft</button>
            <button className="bg-red text-white text-sm font-semibold px-4 py-2 rounded-md hover:opacity-90">Submit for Review</button>
          </div>
        </div>

        <div className="bg-white border border-line rounded-lg p-6 flex flex-col gap-4">
          <input
            type="text"
            value={headline}
            onChange={(e) => setHeadline(e.target.value)}
            placeholder="Headline"
            className="text-2xl font-black outline-none border-b border-line pb-3 placeholder:text-gray-300"
          />
          <input
            type="text"
            value={dek}
            onChange={(e) => setDek(e.target.value)}
            placeholder="Dek / standfirst (one sentence summary)"
            className="text-base outline-none border-b border-line pb-3 placeholder:text-gray-300 text-gray-600"
          />
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Write the article body here…"
            rows={16}
            className="outline-none resize-none text-sm leading-relaxed placeholder:text-gray-300"
          />
        </div>

        {(summary || tags || headlineIdeas || factCheck) && (
          <div className="bg-white border border-line rounded-lg p-6 mt-4 flex flex-col gap-4">
            {summary && (
              <div>
                <h3 className="text-xs font-bold uppercase text-gray-400 mb-1">Summary</h3>
                <p className="text-sm">{summary.summary}</p>
                <ul className="list-disc list-inside text-sm mt-2 text-gray-600">
                  {summary.keyTakeaways.map((k, i) => (
                    <li key={i}>{k}</li>
                  ))}
                </ul>
              </div>
            )}
            {tags && (
              <div>
                <h3 className="text-xs font-bold uppercase text-gray-400 mb-1">Suggested Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {tags.map((t) => (
                    <span key={t} className="text-xs bg-gray-bg px-2 py-1 rounded-full">{t}</span>
                  ))}
                </div>
              </div>
            )}
            {headlineIdeas && (
              <div>
                <h3 className="text-xs font-bold uppercase text-gray-400 mb-1">Headline Options</h3>
                <ul className="text-sm flex flex-col gap-1">
                  {headlineIdeas.map((h, i) => (
                    <li key={i}>
                      <button onClick={() => setHeadline(h)} className="text-left hover:text-red">
                        {h}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {factCheck && (
              <div>
                <h3 className="text-xs font-bold uppercase text-gray-400 mb-1">
                  Fact-Check Triage {factCheck.needsHumanReview && <span className="text-red">· needs human review</span>}
                </h3>
                <ul className="list-disc list-inside text-sm text-gray-600">
                  {factCheck.flags.map((f, i) => (
                    <li key={i}>{f}</li>
                  ))}
                </ul>
                <p className="text-xs text-gray-400 mt-1">{factCheck.reasoning}</p>
              </div>
            )}
          </div>
        )}
      </div>

      <aside className="flex flex-col gap-4">
        <div className="bg-white border border-line rounded-lg p-5">
          <h2 className="text-sm font-bold mb-3">Status</h2>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className="w-full border border-line rounded-md px-3 py-2 text-sm">
            <option>Draft</option>
            <option>In Review</option>
            <option>Scheduled</option>
            <option>Published</option>
          </select>
        </div>

        <div className="bg-white border border-line rounded-lg p-5">
          <h2 className="text-sm font-bold mb-3">Category</h2>
          <select className="w-full border border-line rounded-md px-3 py-2 text-sm">
            {CATEGORY_LIST.map((c) => (
              <option key={c.slug} value={c.slug}>{c.title}</option>
            ))}
          </select>
        </div>

        <div className="bg-white border border-line rounded-lg p-5">
          <h2 className="text-sm font-bold mb-3">Hero Image</h2>
          <div className="border-2 border-dashed border-line rounded-md aspect-video flex items-center justify-center text-xs text-gray-400">
            Drop an image or click to upload
          </div>
        </div>

        <div className="bg-white border border-line rounded-lg p-5">
          <h2 className="text-sm font-bold mb-3 flex items-center gap-2">
            AI Assist
            <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-purple text-white">Gemini</span>
          </h2>
          <div className="flex flex-col gap-2">
            <button
              disabled={aiLoading !== null}
              onClick={() =>
                runAi("summary", async () => setSummary((await aiFunctions.generateSummary(body)).data))
              }
              className="text-xs text-left border border-line rounded-md px-3 py-2 hover:bg-gray-bg disabled:opacity-50"
            >
              {aiLoading === "summary" ? "Thinking…" : "✨ Generate summary"}
            </button>
            <button
              disabled={aiLoading !== null}
              onClick={() => runAi("tags", async () => setTags((await aiFunctions.suggestTags(body)).data.tags))}
              className="text-xs text-left border border-line rounded-md px-3 py-2 hover:bg-gray-bg disabled:opacity-50"
            >
              {aiLoading === "tags" ? "Thinking…" : "🏷️ Suggest tags"}
            </button>
            <button
              disabled={aiLoading !== null}
              onClick={() =>
                runAi("factcheck", async () => setFactCheck((await aiFunctions.factCheckAssist(body)).data))
              }
              className="text-xs text-left border border-line rounded-md px-3 py-2 hover:bg-gray-bg disabled:opacity-50"
            >
              {aiLoading === "factcheck" ? "Thinking…" : "✅ Run fact-check assist"}
            </button>
            <button
              disabled={aiLoading !== null}
              onClick={() =>
                runAi("headlines", async () =>
                  setHeadlineIdeas((await aiFunctions.suggestHeadlines(body)).data.headlines)
                )
              }
              className="text-xs text-left border border-line rounded-md px-3 py-2 hover:bg-gray-bg disabled:opacity-50"
            >
              {aiLoading === "headlines" ? "Thinking…" : "📰 Suggest headlines"}
            </button>
          </div>
          {aiError && <p className="text-[11px] text-red mt-3">{aiError}</p>}
          <p className="text-[11px] text-gray-400 mt-3">
            Calls monalisa-news-firebase (Gemini). Fact-check triage flags claims for a human
            checker — it never asserts true/false. Requires being signed in (same login as the
            rest of the site — Firebase Auth is now the one identity provider).
          </p>
        </div>
      </aside>
    </div>
  );
}
