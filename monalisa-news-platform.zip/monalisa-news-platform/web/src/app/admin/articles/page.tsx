import Link from "next/link";
import { CATEGORY_LIST } from "@/data/categories";

const STATUS_STYLES: Record<string, string> = {
  Published: "bg-green-100 text-green-700",
  "In Review": "bg-blue-100 text-blue-700",
  Draft: "bg-gray-100 text-gray-600",
  Scheduled: "bg-purple-100 text-purple-700",
};

export default function AdminArticlesPage() {
  // Flatten a sample of stories across categories to stand in for
  // `prisma.article.findMany({ orderBy: { updatedAt: "desc" } })`.
  const rows = CATEGORY_LIST.slice(0, 8).map((cat, i) => ({
    id: cat.slug,
    headline: cat.stories[0]?.headline ?? cat.title,
    category: cat.title,
    author: ["Aisha Namboga", "John Mulusimbi", "Diana Nakate", "Brian Tumwesigye"][i % 4],
    status: ["Published", "In Review", "Draft", "Scheduled"][i % 4],
    updated: `${i + 1}h ago`,
  }));

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-black text-navy">Articles</h1>
          <p className="text-sm text-gray-500 mt-1">All articles across every section.</p>
        </div>
        <Link href="/admin/articles/new" className="bg-red text-white text-sm font-semibold px-4 py-2 rounded-md hover:opacity-90">
          + New Article
        </Link>
      </div>

      <div className="bg-white border border-line rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-bg text-gray-500 text-left">
            <tr>
              <th className="font-medium px-4 py-3">Headline</th>
              <th className="font-medium px-4 py-3">Category</th>
              <th className="font-medium px-4 py-3">Author</th>
              <th className="font-medium px-4 py-3">Status</th>
              <th className="font-medium px-4 py-3">Updated</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-line hover:bg-gray-bg/50">
                <td className="px-4 py-3 font-semibold">
                  <Link href="/admin/articles/new" className="hover:text-red">{r.headline}</Link>
                </td>
                <td className="px-4 py-3 text-gray-500">{r.category}</td>
                <td className="px-4 py-3 text-gray-500">{r.author}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-semibold px-2 py-1 rounded ${STATUS_STYLES[r.status]}`}>{r.status}</span>
                </td>
                <td className="px-4 py-3 text-gray-400">{r.updated}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
