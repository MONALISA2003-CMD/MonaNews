"use client";

import Link from "next/link";
import AdminGuard from "@/components/AdminGuard";
import { useAuth } from "@/lib/auth";

const NAV = [
  { href: "/admin", label: "Dashboard", icon: "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z" },
  { href: "/admin/articles", label: "Articles", icon: "M4 4h16v16H4zM8 8h8M8 12h8M8 16h4" },
  { href: "/admin/media", label: "Media Library", icon: "M4 4h16v16H4zM4 15l4-4 4 4 4-6 4 6" },
  { href: "/admin/users", label: "Users", icon: "M9 11a4 4 0 100-8 4 4 0 000 8zM3 21a6 6 0 0112 0M17 11a4 4 0 100-8M21 21a6 6 0 00-6-9" },
];

function AdminShell({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gray-bg flex">
      <aside className="w-60 shrink-0 bg-navy text-white flex flex-col">
        <div className="px-5 py-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="text-lg font-black">MONALISA</span>
            <span className="bg-red text-xs font-black px-1.5 py-0.5 rounded-sm">CMS</span>
          </div>
          <p className="text-xs text-white/50 mt-1">Newsroom Console</p>
        </div>
        <nav className="flex-1 py-4">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 px-5 py-2.5 text-sm text-white/80 hover:bg-white/10 hover:text-white transition-colors"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d={item.icon} stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="px-5 py-4 border-t border-white/10 text-xs text-white/50">
          <p className="font-semibold text-white/80">{user?.name ?? "…"}</p>
          <p>{user?.role.replace(/_/g, " ") ?? ""}</p>
          <div className="flex items-center gap-3 mt-3">
            <Link href="/" className="text-red hover:underline">← Back to site</Link>
            <button onClick={logout} className="text-white/60 hover:text-white">Sign out</button>
          </div>
        </div>
      </aside>
      <main className="flex-1 min-w-0">{children}</main>
    </div>
  );
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <AdminGuard>
      <AdminShell>{children}</AdminShell>
    </AdminGuard>
  );
}
