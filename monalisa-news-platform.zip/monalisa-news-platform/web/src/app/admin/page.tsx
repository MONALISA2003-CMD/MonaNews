// In production these numbers come from aggregate queries against the
// Article/AuditLog models in prisma/schema.prisma.
const STATS = [
  { label: "Published Today", value: "14" },
  { label: "In Review", value: "6" },
  { label: "Scheduled", value: "3" },
  { label: "Drafts", value: "22" },
];

const RECENT_ACTIVITY = [
  { user: "Aisha Namboga", action: "published", target: "Global Leaders Unite At Climate Summit…", time: "12m ago" },
  { user: "John Mulusimbi", action: "submitted for review", target: "Government unveils plan to create 1M jobs…", time: "38m ago" },
  { user: "Diana Nakate", action: "edited", target: "Uganda's exports reach record $6.2B in 2026", time: "1h ago" },
  { user: "Fact Check Desk", action: "flagged", target: "Viral message claiming free money…", time: "2h ago" },
];

export default function AdminDashboard() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-black text-navy">Dashboard</h1>
      <p className="text-sm text-gray-500 mt-1">Newsroom overview for Thursday, July 17, 2026.</p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
        {STATS.map((s) => (
          <div key={s.label} className="bg-white border border-line rounded-lg p-5">
            <span className="text-3xl font-black text-navy">{s.value}</span>
            <p className="text-sm text-gray-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-[1fr_320px] gap-6 mt-8">
        <div className="bg-white border border-line rounded-lg p-6">
          <h2 className="font-bold mb-4">Recent Activity</h2>
          <div className="flex flex-col divide-y divide-line">
            {RECENT_ACTIVITY.map((a, i) => (
              <div key={i} className="py-3 text-sm flex items-start justify-between gap-4">
                <div>
                  <span className="font-semibold">{a.user}</span>{" "}
                  <span className="text-gray-500">{a.action}</span>{" "}
                  <span className="text-gray-700">&quot;{a.target}&quot;</span>
                </div>
                <span className="text-xs text-gray-400 shrink-0">{a.time}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white border border-line rounded-lg p-6">
          <h2 className="font-bold mb-4">Editorial Pipeline</h2>
          <ul className="space-y-3 text-sm">
            <li className="flex justify-between"><span>Draft</span><span className="font-semibold">22</span></li>
            <li className="flex justify-between"><span>In Review</span><span className="font-semibold">6</span></li>
            <li className="flex justify-between"><span>Fact-Check Pending</span><span className="font-semibold">3</span></li>
            <li className="flex justify-between"><span>Scheduled</span><span className="font-semibold">3</span></li>
            <li className="flex justify-between"><span>Published Today</span><span className="font-semibold">14</span></li>
          </ul>
        </div>
      </div>
    </div>
  );
}
