"use client";

import { useState, useEffect } from "react";
import { apiClient } from "@/lib/api-client";
import { auth } from "@/lib/firebase";

interface UserRow {
  id: string;
  name: string;
  email: string;
  role: string;
  beat: string | null;
  createdAt: string;
}

const ROLES = [
  "SUBSCRIBER",
  "ADVERTISER",
  "PHOTOGRAPHER",
  "VIDEO_EDITOR",
  "PODCAST_PRODUCER",
  "MODERATOR",
  "FACT_CHECKER",
  "JOURNALIST",
  "EDITOR",
  "EDITOR_IN_CHIEF",
  "SUPER_ADMIN",
];

export default function AdminUsersPage() {
  const [users, setUsers] = useState<UserRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savingId, setSavingId] = useState<string | null>(null);

  const load = async () => {
    if (!auth.currentUser) return;
    try {
      const token = await auth.currentUser.getIdToken();
      const list = (await apiClient.getUsers(token)) as UserRow[];
      setUsers(list);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't load users. Are you a Super Admin or Editor-in-Chief?");
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const changeRole = async (userId: string, role: string) => {
    if (!auth.currentUser) return;
    setSavingId(userId);
    try {
      const token = await auth.currentUser.getIdToken();
      await apiClient.updateUserRole(token, userId, role);
      setUsers((prev) => prev?.map((u) => (u.id === userId ? { ...u, role } : u)) ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't update role.");
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-black text-navy">Users</h1>
      <p className="text-sm text-gray-500 mt-1">
        Manage roles. Only Super Admins and Editors-in-Chief can see this page — enforced by the API,
        not just hidden in the UI.
      </p>

      {error && <p className="text-sm text-red mt-4">{error}</p>}

      {!users ? (
        <p className="text-sm text-gray-400 mt-6">Loading…</p>
      ) : (
        <div className="bg-white border border-line rounded-lg overflow-hidden mt-6">
          <table className="w-full text-sm">
            <thead className="bg-gray-bg text-gray-500 text-left">
              <tr>
                <th className="font-medium px-4 py-3">Name</th>
                <th className="font-medium px-4 py-3">Email</th>
                <th className="font-medium px-4 py-3">Role</th>
                <th className="font-medium px-4 py-3">Joined</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-t border-line">
                  <td className="px-4 py-3 font-semibold">{u.name}</td>
                  <td className="px-4 py-3 text-gray-500">{u.email}</td>
                  <td className="px-4 py-3">
                    <select
                      value={u.role}
                      disabled={savingId === u.id}
                      onChange={(e) => changeRole(u.id, e.target.value)}
                      className="border border-line rounded-md px-2 py-1 text-xs disabled:opacity-50"
                    >
                      {ROLES.map((r) => (
                        <option key={r} value={r}>{r.replace(/_/g, " ")}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-3 text-gray-400">{new Date(u.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
