"use client";

import Image from "next/image";

const VIDEOS = [
  { seed: "vh1", title: "Morning Brief: the five stories to know today", duration: "4:12" },
  { seed: "vh2", title: "One-on-one: the Finance Minister on next year's budget", duration: "11:03" },
  { seed: "vh3", title: "Tech Trends: what to expect in the next 6 months", duration: "6:35" },
];

const PODCASTS = [
  { seed: "pod1", title: "The Weekly Brief — episode 112: rate decisions, decoded", duration: "34 min" },
  { seed: "pod2", title: "Off the Record — East Africa's creative economy", duration: "41 min" },
];

export default function VideoHubPage() {
  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-3xl sm:text-4xl font-black text-navy mb-2">Watch &amp; Listen</h1>
      <p className="text-sm text-gray-500 mb-8">
        Video reporting, live coverage, and the newsroom&apos;s podcasts, all in one place.
      </p>

      <h2 className="text-lg font-black tracking-tight mb-4">Videos</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-12">
        {VIDEOS.map((v) => (
          <button key={v.seed} onClick={() => alert("Video would play here.")} className="group card overflow-hidden text-left">
            <div className="relative aspect-video w-full">
              <Image src={`https://picsum.photos/seed/${v.seed}/360/220`} alt="" fill className="object-cover" />
              <span className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-1.5 py-0.5 rounded">{v.duration}</span>
            </div>
            <div className="p-3">
              <h3 className="text-sm font-bold leading-snug">{v.title}</h3>
            </div>
          </button>
        ))}
      </div>

      <h2 id="podcasts" className="text-lg font-black tracking-tight mb-4 scroll-mt-24">Podcasts</h2>
      <div className="flex flex-col divide-y divide-line card overflow-hidden">
        {PODCASTS.map((p) => (
          <div key={p.seed} className="flex items-center gap-4 p-4">
            <div className="relative w-14 h-14 rounded-md overflow-hidden shrink-0">
              <Image src={`https://picsum.photos/seed/${p.seed}/120/120`} alt="" fill className="object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-sm leading-snug">{p.title}</h3>
              <span className="text-xs text-gray-500">{p.duration}</span>
            </div>
            <button
              onClick={() => alert("Episode would start playing here.")}
              className="w-9 h-9 rounded-full bg-navy text-white flex items-center justify-center shrink-0"
              aria-label="Play episode"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z" /></svg>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
