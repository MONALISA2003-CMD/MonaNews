"use client";

import { useState } from "react";

const NEWSLETTERS = [
  { id: "morning-brief", name: "Morning Brief", cadence: "Daily", desc: "The five stories to know, delivered every weekday before 7 AM." },
  { id: "weekend-reads", name: "Weekend Reads", cadence: "Weekly", desc: "Longer stories for slower days, every Saturday." },
  { id: "politics-weekly", name: "Politics Weekly", cadence: "Weekly", desc: "A Friday digest of the week's biggest political stories." },
  { id: "markets-daily", name: "Markets Daily", cadence: "Daily", desc: "Prices, moves, and context before the opening bell." },
  { id: "breaking-alerts", name: "Breaking News Alerts", cadence: "Instant", desc: "Confirmed major developments, sent the moment they're verified." },
];

export default function NewslettersPage() {
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const toggle = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8 grid lg:grid-cols-[1fr_360px] gap-10">
      <div>
        <h1 className="text-3xl sm:text-4xl font-black text-navy mb-2">Newsletters</h1>
        <p className="text-sm text-gray-500 mb-6">Pick the briefings that fit your day.</p>
        <div className="flex flex-col divide-y divide-line">
          {NEWSLETTERS.map((n) => (
            <label key={n.id} className="flex items-start gap-4 py-6 cursor-pointer">
              <input
                type="checkbox"
                checked={selected.has(n.id)}
                onChange={() => toggle(n.id)}
                className="mt-1.5 w-5 h-5 accent-red"
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold uppercase px-2 py-0.5 rounded bg-navy text-white">{n.cadence}</span>
                  <h3 className="font-bold text-lg">{n.name}</h3>
                </div>
                <p className="text-sm text-gray-600 mt-1">{n.desc}</p>
              </div>
            </label>
          ))}
        </div>
      </div>

      <aside>
        <div className="card p-6 sticky top-24">
          <h2 className="font-black text-lg text-navy">Get Started</h2>
          <p className="text-sm text-gray-500 mt-1">{selected.size} newsletter{selected.size === 1 ? "" : "s"} selected.</p>
          <form
            className="mt-4 flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              alert(`Would subscribe this address to: ${[...selected].join(", ") || "nothing selected"}`);
            }}
          >
            <input type="email" required placeholder="Email address" className="border border-line rounded-md px-3 py-2.5 text-sm" />
            <button type="submit" className="bg-red text-white text-sm font-semibold py-2.5 rounded-md hover:opacity-90">
              Subscribe
            </button>
          </form>
        </div>
      </aside>
    </div>
  );
}
