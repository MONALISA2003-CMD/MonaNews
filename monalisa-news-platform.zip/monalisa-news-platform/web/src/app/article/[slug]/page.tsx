import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Badge from "@/components/Badge";
import { getAuthor } from "@/data/authors";
import { resolveArticle, allKnownArticleSlugs } from "@/lib/resolve-article";
import { getCategory } from "@/data/categories";
import CommentSection from "./CommentSection";
import {
  ProgressBar,
  TextSizeControls,
  SaveButton,
  ListenButton,
  TranslateButton,
  ShareButton,
  TableOfContents,
} from "./ReadingTools";

export function generateStaticParams() {
  return allKnownArticleSlugs().map((slug) => ({ slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const resolved = resolveArticle(params.slug);
  if (!resolved) return { title: "Article not found — MONALISA NEWS" };
  const headline = resolved.kind === "full" ? resolved.article.headline : resolved.headline;
  return { title: `${headline} — MONALISA NEWS` };
}

export default function ArticlePage({ params }: { params: { slug: string } }) {
  // Previously this page ignored params.slug entirely and always rendered
  // the same hardcoded climate summit article — every headline across the
  // whole site linked here. Fixed via resolveArticle(): a handful of
  // slugs get a full hand-written article, every other real story slug
  // gets a lighter render built from its own data, and an unknown slug
  // now correctly 404s instead of silently showing someone else's story.
  const resolved = resolveArticle(params.slug);
  if (!resolved) notFound();

  if (resolved.kind === "generic") {
    const category = getCategory(resolved.categorySlug);
    return (
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8 max-w-3xl">
        <div className="text-xs text-gray-500 mb-4">
          <Link href="/" className="hover:text-red">Home</Link> /{" "}
          <Link href={`/category/${category.slug}`} className="hover:text-red">{category.title}</Link>
        </div>
        <Badge color={resolved.badge}>{resolved.label}</Badge>
        <h1 className="text-3xl sm:text-4xl font-black leading-tight mt-4 text-navy">{resolved.headline}</h1>
        <span className="text-xs text-gray-500 block mt-3">{resolved.meta}</span>
        <div className="relative aspect-[16/9] w-full rounded-lg overflow-hidden mt-6">
          <Image src={`https://picsum.photos/seed/${resolved.slug}/1100/620`} alt="" fill className="object-cover" />
        </div>
        <p className="text-base leading-relaxed mt-6 text-gray-700">
          Full reporting on this story is still being written up for the site. In the meantime, here&apos;s what
          we know: {resolved.headline.toLowerCase()}. Check back soon, or explore related coverage in{" "}
          <Link href={`/category/${category.slug}`} className="text-blue hover:underline">{category.title}</Link>.
        </p>
        <p className="text-xs text-gray-400 mt-8">
          (This is a lighter placeholder render — see src/data/articles.ts to add the full story.)
        </p>
      </div>
    );
  }

  const { article } = resolved;
  const author = getAuthor(article.authorSlug);
  const sections = article.sections.map((s) => ({ id: s.id, label: s.heading }));
  const publishedLabel = new Date(article.publishedAt).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    headline: article.headline,
    description: article.dek,
    datePublished: article.publishedAt,
    dateModified: article.publishedAt,
    author: { "@type": "Person", name: author.name },
    publisher: {
      "@type": "Organization",
      name: "Monalisa News",
      logo: { "@type": "ImageObject", url: `${process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"}/icon.svg` },
    },
    image: [`https://picsum.photos/seed/${article.heroSeed}/1100/620`],
    articleSection: article.categoryTitle,
    keywords: article.tags.join(", "),
  };

  return (
    <>
      {/* eslint-disable-next-line react/no-danger -- JSON-LD requires raw script injection, no user input involved */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <ProgressBar />

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 pt-4 text-xs text-gray-500">
        <Link href="/" className="hover:text-red">Home</Link> /{" "}
        <Link href={`/category/${article.categorySlug}`} className="hover:text-red">{article.categoryTitle}</Link> /{" "}
        <span className="text-gray-700">{article.headline}</span>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-6 grid lg:grid-cols-[220px_1fr_320px] gap-8">
        <aside className="hidden lg:block">
          <div className="sticky top-24">
            <span className="text-xs font-black tracking-wide text-gray-400">TABLE OF CONTENTS</span>
            <TableOfContents sections={sections} />
            <div className="mt-6 pt-6 border-t border-line">
              <span className="text-xs font-black tracking-wide text-gray-400">TEXT SIZE</span>
              <TextSizeControls />
            </div>
          </div>
        </aside>

        <article>
          <Badge color={article.badge}>{article.categoryTitle}</Badge>
          <h1 className="text-3xl sm:text-5xl font-black leading-tight mt-4 text-navy">{article.headline}</h1>
          <p className="text-lg text-gray-600 mt-4 leading-relaxed">{article.dek}</p>

          <div className="flex flex-wrap items-center justify-between gap-4 mt-6 py-4 border-y border-line">
            <div className="flex items-center gap-3">
              <div className="relative w-11 h-11 rounded-full overflow-hidden">
                <Image src={`https://picsum.photos/seed/${author.slug}/80/80`} alt="" fill className="object-cover" />
              </div>
              <div className="text-sm">
                <Link href={`/author/${author.slug}`} className="font-bold block hover:text-red">
                  By {author.name}
                </Link>
                <span className="text-gray-500 text-xs">{publishedLabel} · {article.readingTimeMin} min read</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <SaveButton articleSlug={article.slug} />
              <ListenButton headline={article.headline} sections={article.sections} />
              <TranslateButton />
              <ShareButton />
            </div>
          </div>

          <figure className="mt-6">
            <div className="relative aspect-[16/9] w-full rounded-lg overflow-hidden">
              <Image src={`https://picsum.photos/seed/${article.heroSeed}/1100/620`} alt="" fill className="object-cover" priority />
            </div>
          </figure>

          <div id="articleBody" className="mt-8 leading-[1.85]" style={{ fontSize: 18 }}>
            {article.sections.map((s) => (
              <div key={s.id}>
                <h2 id={s.id} className="text-2xl font-extrabold mt-6 mb-3 text-navy">{s.heading}</h2>
                {s.paragraphs.map((p, i) => (
                  <p key={i} className="mb-6">{p}</p>
                ))}
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-2 mt-8 pt-6 border-t border-line">
            {article.tags.map((t) => (
              <span key={t} className="text-xs bg-gray-bg px-3 py-1.5 rounded-full">{t}</span>
            ))}
          </div>

          <div className="card p-5 mt-6 flex items-center gap-4">
            <div className="relative w-14 h-14 rounded-full overflow-hidden shrink-0">
              <Image src={`https://picsum.photos/seed/${author.slug}/80/80`} alt="" fill className="object-cover" />
            </div>
            <div>
              <Link href={`/author/${author.slug}`} className="font-bold block hover:text-red">
                {author.name}
              </Link>
              <p className="text-sm text-gray-500 mt-1">{author.bio}</p>
            </div>
          </div>

          <CommentSection articleSlug={article.slug} />
        </article>

        <aside className="flex flex-col gap-4">
          <div className="card p-4">
            <h2 className="text-sm font-black tracking-tight mb-3">MOST READ</h2>
            <p className="text-xs text-gray-500">See the homepage sidebar for live rankings.</p>
          </div>
        </aside>
      </div>
    </>
  );
}
