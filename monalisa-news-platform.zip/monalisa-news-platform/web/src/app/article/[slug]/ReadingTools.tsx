"use client";

import { useState, useEffect, useRef } from "react";
import { isArticleSaved, toggleSavedArticle } from "@/lib/saved-articles";
import type { ArticleSection } from "@/data/articles";

export function ProgressBar() {
  const [pct, setPct] = useState(0);

  useEffect(() => {
    const el = document.getElementById("articleBody");
    if (!el) return;
    const start = el.getBoundingClientRect().top + window.scrollY - 100;
    const end = start + el.offsetHeight;
    const onScroll = () => {
      const p = Math.min(100, Math.max(0, ((window.scrollY - start) / (end - start)) * 100));
      setPct(p);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return <div className="fixed top-0 left-0 h-[3px] bg-red z-[60] transition-[width]" style={{ width: `${pct}%` }} />;
}

export function TextSizeControls() {
  const [size, setSize] = useState(18);
  useEffect(() => {
    document.getElementById("articleBody")?.style.setProperty("font-size", `${size}px`);
  }, [size]);

  return (
    <div className="flex items-center gap-2 mt-2">
      <button onClick={() => setSize((s) => Math.max(14, s - 2))} className="w-8 h-8 border border-line rounded-md text-xs font-bold hover:bg-gray-bg">A-</button>
      <button onClick={() => setSize(18)} className="w-8 h-8 border border-line rounded-md text-sm font-bold hover:bg-gray-bg">A</button>
      <button onClick={() => setSize((s) => Math.min(24, s + 2))} className="w-8 h-8 border border-line rounded-md text-base font-bold hover:bg-gray-bg">A+</button>
    </div>
  );
}

// Persists to localStorage (see src/lib/saved-articles.ts) — genuinely
// survives a page refresh, unlike the previous version which was pure
// in-memory React state that reset on reload. Not wired to the API's
// SavedArticle model yet: that table keys off a real Article row, and
// these article slugs are currently frontend-only content (see
// src/data/articles.ts) with no matching backend row to attach to.
export function SaveButton({ articleSlug }: { articleSlug: string }) {
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setSaved(isArticleSaved(articleSlug));
  }, [articleSlug]);

  return (
    <button
      onClick={() => setSaved(toggleSavedArticle(articleSlug))}
      aria-pressed={saved}
      aria-label="Save for later"
      title="Save for later"
      className="w-9 h-9 border border-line rounded-full flex items-center justify-center hover:bg-gray-bg"
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill={saved ? "#DA1E28" : "none"}>
        <path d="M6 3h12v18l-6-4-6 4z" stroke={saved ? "#DA1E28" : "#111827"} strokeWidth="2" />
      </svg>
    </button>
  );
}

// Real audio narration via the browser's built-in SpeechSynthesis API —
// no backend, no API key, works offline. Previously this button was an
// alert() placeholder. Trade-off: quality and voice selection depend
// entirely on the browser/OS (Chrome/Edge on desktop sound best; iOS
// Safari and some Android browsers have thinner voice options). A
// server-rendered narration (e.g. via a real TTS API) would sound more
// consistent across devices — this is the zero-infrastructure version.
export function ListenButton({ headline, sections }: { headline: string; sections: ArticleSection[] }) {
  const [state, setState] = useState<"idle" | "playing" | "paused" | "unsupported">("idle");

  useEffect(() => {
    if (typeof window !== "undefined" && !("speechSynthesis" in window)) {
      setState("unsupported");
    }
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleClick = () => {
    if (state === "unsupported") return;

    if (state === "playing") {
      window.speechSynthesis.pause();
      setState("paused");
      return;
    }
    if (state === "paused") {
      window.speechSynthesis.resume();
      setState("playing");
      return;
    }

    const text = [headline, ...sections.flatMap((s) => [s.heading, ...s.paragraphs])].join(". ");
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.onend = () => setState("idle");
    utterance.onerror = () => setState("idle");
    window.speechSynthesis.cancel(); // clear any previous utterance first
    window.speechSynthesis.speak(utterance);
    setState("playing");
  };

  const label = state === "playing" ? "Pause narration" : state === "paused" ? "Resume narration" : "Listen to article";

  return (
    <button
      onClick={handleClick}
      disabled={state === "unsupported"}
      className="w-9 h-9 border border-line rounded-full flex items-center justify-center hover:bg-gray-bg disabled:opacity-40"
      aria-label={label}
      title={state === "unsupported" ? "Not supported in this browser" : label}
    >
      {state === "playing" ? (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="#111827"><rect x="6" y="5" width="4" height="14" /><rect x="14" y="5" width="4" height="14" /></svg>
      ) : (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
          <path d="M11 5L6 9H3v6h3l5 4V5z" stroke="#111827" strokeWidth="2" strokeLinejoin="round" />
          <path d="M16 8a5 5 0 010 8" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
        </svg>
      )}
    </button>
  );
}

// Opens the current page through Google Translate's web viewer — a real,
// working, zero-API-key translation (Google's public translate.google.com
// proxy) rather than an alert() placeholder. It navigates away from the
// site rather than translating in place, which is the trade-off for not
// needing a paid Cloud Translation API integration; swap this for a real
// in-page translation once that's worth the API cost.
export function TranslateButton() {
  const handleClick = () => {
    const url = `https://translate.google.com/translate?sl=auto&tl=en&u=${encodeURIComponent(window.location.href)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <button
      onClick={handleClick}
      className="w-9 h-9 border border-line rounded-full flex items-center justify-center hover:bg-gray-bg"
      aria-label="Translate article"
      title="Translate"
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
        <path d="M4 5h9M9 3v2m0 0c0 4-2 7-5 9m5-9c1.5 2 3 3 5 4M13 21l4-9 4 9m-7-3h6" stroke="#111827" strokeWidth="1.7" strokeLinecap="round" />
      </svg>
    </button>
  );
}

export function ShareButton() {
  return (
    <button
      onClick={() => {
        if (navigator.share) {
          navigator.share({ title: document.title, url: location.href });
        } else {
          navigator.clipboard?.writeText(location.href);
          alert("Link copied to clipboard.");
        }
      }}
      className="w-9 h-9 border border-line rounded-full flex items-center justify-center hover:bg-gray-bg"
      aria-label="Share"
      title="Share"
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
        <circle cx="18" cy="5" r="2.5" stroke="#111827" strokeWidth="1.7" />
        <circle cx="6" cy="12" r="2.5" stroke="#111827" strokeWidth="1.7" />
        <circle cx="18" cy="19" r="2.5" stroke="#111827" strokeWidth="1.7" />
        <path d="M8.2 10.7l7.6-4.4M8.2 13.3l7.6 4.4" stroke="#111827" strokeWidth="1.7" />
      </svg>
    </button>
  );
}

export function TableOfContents({ sections }: { sections: { id: string; label: string }[] }) {
  const [active, setActive] = useState(sections[0]?.id);
  const ticking = useRef(false);

  useEffect(() => {
    const onScroll = () => {
      if (ticking.current) return;
      ticking.current = true;
      requestAnimationFrame(() => {
        let current = sections[0]?.id;
        for (const s of sections) {
          const el = document.getElementById(s.id);
          if (el && window.scrollY >= el.offsetTop - 140) current = s.id;
        }
        setActive(current);
        ticking.current = false;
      });
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, [sections]);

  return (
    <ul className="mt-3 space-y-2 text-sm border-l-2 border-line pl-3">
      {sections.map((s) => (
        <li key={s.id}>
          <a
            href={`#${s.id}`}
            className={`block border-l-2 -ml-3.5 pl-3 py-0.5 ${
              active === s.id ? "border-red text-red font-bold" : "border-transparent text-gray-500"
            }`}
          >
            {s.label}
          </a>
        </li>
      ))}
    </ul>
  );
}
