"use client";

import { useState, useEffect } from "react";
import { apiClient } from "@/lib/api-client";
import { auth } from "@/lib/firebase";
import { useAuth } from "@/lib/auth";

interface CommentRecord {
  id: string;
  body: string;
  createdAt: string;
  author: { id: string; name: string };
}

export default function CommentSection({ articleSlug }: { articleSlug: string }) {
  const { user } = useAuth();
  const [articleId, setArticleId] = useState<string | null>(null);
  const [comments, setComments] = useState<CommentRecord[]>([]);
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unavailable, setUnavailable] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        // Resolves the real DB id for this slug — comments key off that,
        // not the frontend slug. Only the articles seeded by
        // prisma/seed.ts (the same 5 in src/data/articles.ts) will
        // resolve; anything else means the API/DB isn't reachable or
        // this particular article hasn't been seeded as a real row yet.
        const article = (await apiClient.getArticle(articleSlug)) as { id: string };
        if (cancelled) return;
        setArticleId(article.id);
        const list = (await apiClient.getComments(article.id)) as CommentRecord[];
        if (!cancelled) setComments(list);
      } catch {
        if (!cancelled) setUnavailable(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [articleSlug]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!articleId || !auth.currentUser || !draft.trim()) return;
    setSubmitting(true);
    setError(null);
    try {
      const token = await auth.currentUser.getIdToken();
      await apiClient.postComment(token, articleId, draft.trim());
      setDraft("");
      // New comments start unapproved (see comments.module.ts) — surface
      // that instead of silently making it look like it appeared publicly.
      setError("Comment submitted — it'll appear once a moderator approves it.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't post comment.");
    } finally {
      setSubmitting(false);
    }
  };

  if (unavailable) return null; // API down or article not seeded — fail quiet, don't break the page
  if (loading) return <div className="text-sm text-gray-400 mt-10">Loading comments…</div>;

  return (
    <div className="mt-10 pt-8 border-t border-line">
      <h2 className="text-lg font-black tracking-tight mb-4">
        Comments {comments.length > 0 && <span className="text-gray-400 font-normal">({comments.length})</span>}
      </h2>

      {user ? (
        <form onSubmit={handleSubmit} className="mb-6">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Add a comment…"
            rows={3}
            maxLength={2000}
            className="w-full border border-line rounded-md px-3 py-2 text-sm resize-none"
          />
          <div className="flex items-center justify-between mt-2">
            {error && <p className="text-xs text-gray-500">{error}</p>}
            <button
              type="submit"
              disabled={submitting || !draft.trim()}
              className="ml-auto bg-red text-white text-xs font-semibold px-4 py-2 rounded-md hover:opacity-90 disabled:opacity-50"
            >
              {submitting ? "Posting…" : "Post Comment"}
            </button>
          </div>
        </form>
      ) : (
        <p className="text-sm text-gray-500 mb-6">
          <a href="/login" className="text-blue hover:underline">Sign in</a> to leave a comment.
        </p>
      )}

      {comments.length === 0 ? (
        <p className="text-sm text-gray-400">No comments yet — be the first.</p>
      ) : (
        <div className="flex flex-col gap-4">
          {comments.map((c) => (
            <div key={c.id} className="text-sm">
              <span className="font-semibold">{c.author.name}</span>{" "}
              <span className="text-gray-400 text-xs">{new Date(c.createdAt).toLocaleDateString()}</span>
              <p className="text-gray-700 mt-1">{c.body}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
