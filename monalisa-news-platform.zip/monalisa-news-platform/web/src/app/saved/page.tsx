"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { getSavedArticleSlugs, toggleSavedArticle } from "@/lib/saved-articles";
import { resolveArticle } from "@/lib/resolve-article";
import Badge from "@/components/Badge";

export default function SavedArticlesPage() {
  const [slugs, setSlugs] = useState<string[]>([]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setSlugs(getSavedArticleSlugs());
    setMounted(true);
  }, []);

  const remove = (slug: string) => {
    toggleSavedArticle(slug);
    setSlugs(getSavedArticleSlugs());
  };

  if (!mounted) return null; // avoid a localStorage-vs-server render mismatch flash

  const resolved = slugs.map((slug) => ({ slug, data: resolveArticle(slug) })).filter((r) => r.data !== null);

  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-3xl sm:text-4xl font-black text-navy mb-2">Saved Articles</h1>
      <p className="text-sm text-gray-500 mb-8">
        Saved on this device only — see the Save button on any article. {resolved.length} saved.
      </p>

      {resolved.length === 0 ? (
        <div className="card p-8 text-center text-gray-500">
          <p>Nothing saved yet.</p>
          <Link href="/" className="text-blue hover:underline text-sm mt-2 inline-block">Browse the homepage →</Link>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {resolved.map(({ slug, data }) => {
            const headline = data!.kind === "full" ? data!.article.headline : data!.headline;
            const badge = data!.kind === "full" ? data!.article.badge : data!.badge;
            const label = data!.kind === "full" ? data!.article.categoryTitle : data!.label;
            const seed = data!.kind === "full" ? data!.article.heroSeed : slug;
            return (
              <div key={slug} className="card overflow-hidden relative group">
                <button
                  onClick={() => remove(slug)}
                  className="absolute top-2 right-2 z-10 w-7 h-7 rounded-full bg-white/90 flex items-center justify-center hover:bg-white shadow"
                  aria-label="Remove from saved"
                  title="Remove from saved"
                >
                  ✕
                </button>
                <Link href={`/article/${slug}`}>
                  <div className="relative aspect-[3/2] w-full">
                    <Image src={`https://picsum.photos/seed/${seed}/420/260`} alt="" fill className="object-cover" />
                  </div>
                  <div className="p-3">
                    <Badge color={badge}>{label}</Badge>
                    <h3 className="font-bold leading-snug mt-2 hover:text-red transition-colors">{headline}</h3>
                  </div>
                </Link>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
