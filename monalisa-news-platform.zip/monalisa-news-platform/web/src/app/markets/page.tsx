"use client";

import { useState } from "react";

// In production these arrays are replaced by a live market-data feed
// (e.g. polled from a provider API and cached in Redis — see README).
const STOCKS = [
  { symbol: "UMEME", name: "Umeme Ltd", price: "312.00", change: "+1.4%", up: true },
  { symbol: "SBU", name: "Stanbic Bank Uganda", price: "42.50", change: "-0.6%", up: false },
  { symbol: "EABL", name: "East African Breweries", price: "168.75", change: "+0.9%", up: true },
  { symbol: "SCOM", name: "Safaricom", price: "28.90", change: "+2.1%", up: true },
];
const CURRENCIES = [
  { symbol: "USD/UGX", price: "3,689.00", change: "+0.21%", up: true },
  { symbol: "EUR/UGX", price: "4,096.50", change: "-0.15%", up: false },
  { symbol: "GBP/UGX", price: "4,782.10", change: "+0.08%", up: true },
];
const COMMODITIES = [
  { symbol: "Gold (per oz)", price: "2,295.40", change: "+0.72%", up: true },
  { symbol: "Oil (Brent, per barrel)", price: "84.45", change: "+0.31%", up: true },
];
const CRYPTO = [
  { symbol: "Bitcoin (BTC)", price: "$61,240", change: "+2.1%", up: true },
  { symbol: "Ethereum (ETH)", price: "$3,410", change: "+1.4%", up: true },
];

const TABS = {
  Stocks: STOCKS,
  Currencies: CURRENCIES,
  Commodities: COMMODITIES,
  Crypto: CRYPTO,
} as const;

export default function MarketsPage() {
  const [active, setActive] = useState<keyof typeof TABS>("Stocks");

  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-3xl sm:text-4xl font-black text-navy mb-2">Markets</h1>
      <p className="text-sm text-gray-500 mb-8">Live prices across East African and global exchanges.</p>

      <div className="flex gap-6 text-sm border-b border-line">
        {(Object.keys(TABS) as (keyof typeof TABS)[]).map((tab) => (
          <button
            key={tab}
            onClick={() => setActive(tab)}
            className={`pb-3 border-b-2 ${active === tab ? "border-navy font-bold text-navy" : "border-transparent text-gray-500"}`}
          >
            {tab}
          </button>
        ))}
      </div>

      <table className="w-full text-sm mt-4">
        <thead>
          <tr className="text-gray-400 text-left border-b border-line">
            <th className="font-medium pb-2">Symbol</th>
            <th className="font-medium pb-2 text-right">Price</th>
            <th className="font-medium pb-2 text-right">Change</th>
          </tr>
        </thead>
        <tbody>
          {TABS[active].map((row) => (
            <tr key={row.symbol} className="border-b border-line">
              <td className="py-2.5 font-semibold">{row.symbol}</td>
              <td className="text-right">{row.price}</td>
              <td className={`text-right ${row.up ? "text-green-600" : "text-red"}`}>{row.change}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
