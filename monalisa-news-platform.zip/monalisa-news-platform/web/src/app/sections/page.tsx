import Link from "next/link";
import { CATEGORY_LIST } from "@/data/categories";

export default function SectionsPage() {
  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-3xl sm:text-4xl font-black text-navy mb-2">All Sections</h1>
      <p className="text-sm text-gray-500 mb-8">Every section of Monalisa News, in one place.</p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {CATEGORY_LIST.map((cat) => (
          <Link key={cat.slug} href={`/category/${cat.slug}`} className="card p-4 flex items-center gap-3 hover:border-red group">
            <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${cat.color}`} />
            <span className="font-semibold text-sm group-hover:text-red transition-colors">{cat.title}</span>
          </Link>
        ))}
        <Link href="/markets" className="card p-4 flex items-center gap-3 hover:border-red group">
          <span className="w-2.5 h-2.5 rounded-full shrink-0 bg-navy" />
          <span className="font-semibold text-sm group-hover:text-red transition-colors">Markets</span>
        </Link>
        <Link href="/video-hub" className="card p-4 flex items-center gap-3 hover:border-red group">
          <span className="w-2.5 h-2.5 rounded-full shrink-0 bg-blue" />
          <span className="font-semibold text-sm group-hover:text-red transition-colors">Watch &amp; Listen</span>
        </Link>
        <Link href="/live-blog" className="card p-4 flex items-center gap-3 hover:border-red group">
          <span className="w-2.5 h-2.5 rounded-full shrink-0 bg-red" />
          <span className="font-semibold text-sm group-hover:text-red transition-colors">Live Blogs</span>
        </Link>
        <Link href="/newsletters" className="card p-4 flex items-center gap-3 hover:border-red group">
          <span className="w-2.5 h-2.5 rounded-full shrink-0 bg-navy" />
          <span className="font-semibold text-sm group-hover:text-red transition-colors">Newsletters</span>
        </Link>
      </div>
    </div>
  );
}
