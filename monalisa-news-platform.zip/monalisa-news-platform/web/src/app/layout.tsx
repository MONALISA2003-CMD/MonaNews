import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import UtilityBar from "@/components/UtilityBar";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ServiceWorkerRegistration from "@/components/ServiceWorkerRegistration";

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800", "900"],
  variable: "--font-inter",
});

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: "MONALISA NEWS — Real News. Real Impact.",
  description:
    "A world-class AI-powered digital news platform covering politics, business, technology, sports, and more.",
  manifest: "/manifest.json",
  openGraph: {
    type: "website",
    siteName: "Monalisa News",
    title: "MONALISA NEWS — Real News. Real Impact.",
    description: "A world-class AI-powered digital news platform.",
    url: SITE_URL,
  },
  twitter: {
    card: "summary_large_image",
    title: "MONALISA NEWS — Real News. Real Impact.",
    description: "A world-class AI-powered digital news platform.",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="font-sans text-ink bg-white">
        <ServiceWorkerRegistration />
        <UtilityBar />
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}
