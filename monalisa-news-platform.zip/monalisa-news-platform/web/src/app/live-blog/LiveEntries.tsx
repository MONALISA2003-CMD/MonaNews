"use client";

import { useState, useEffect } from "react";
import { io } from "socket.io-client";
import { API_URL } from "@/lib/api-client";

export interface LiveEntry {
  id: string;
  title: string;
  body: string;
  tag?: string | null;
  postedAt: string;
}

function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

export default function LiveEntries({ liveBlogId, slug, initialEntries }: { liveBlogId: string; slug: string; initialEntries: LiveEntry[] }) {
  const [entries, setEntries] = useState(initialEntries);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const wsUrl = API_URL.replace(/\/api\/v1\/?$/, ""); // gateway isn't under the /api/v1 REST prefix

    const socket = io(`${wsUrl}/live-blog`, { transports: ["websocket"], reconnectionAttempts: 5 });

    socket.on("connect", () => {
      setConnected(true);
      socket.emit("join", liveBlogId); // matches the room name broadcastNewEntry() targets
    });
    socket.on("disconnect", () => setConnected(false));
    socket.on("new-entry", (entry: LiveEntry) => {
      setEntries((prev) => [entry, ...prev]);
    });

    return () => {
      socket.disconnect();
    };
  }, [liveBlogId]);

  return (
    <div>
      <div className="flex items-center gap-1.5 text-xs text-gray-400 mb-4">
        <span className={`w-1.5 h-1.5 rounded-full ${connected ? "bg-green-500" : "bg-gray-300"}`} />
        {connected ? "Live — updates automatically" : "Reconnecting…"}
        <span className="text-gray-300">· {slug}</span>
      </div>
      <div className="flex flex-col gap-8 max-w-2xl">
        {entries.map((e, i) => (
          <div key={e.id} className="relative pl-7">
            <span className="absolute left-1.5 top-1.5 w-2.5 h-2.5 rounded-full bg-red" />
            {i < entries.length - 1 && <span className="absolute left-[9px] top-4 bottom-[-32px] w-0.5 bg-line" />}
            <div className="flex items-baseline gap-2">
              <span className="text-sm font-black text-navy">{formatTime(e.postedAt)}</span>
              {e.tag && <span className="text-[11px] font-bold uppercase px-2 py-0.5 rounded bg-navy text-white">{e.tag}</span>}
            </div>
            <h3 className="font-bold text-lg mt-1 leading-snug">{e.title}</h3>
            <p className="text-sm text-gray-600 mt-1">{e.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
