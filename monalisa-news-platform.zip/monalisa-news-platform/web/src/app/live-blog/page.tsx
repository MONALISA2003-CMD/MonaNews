import { apiClient } from "@/lib/api-client";
import LiveEntries, { type LiveEntry } from "./LiveEntries";

const SLUG = "climate-summit-closing";

// Mirrors what prisma/seed.ts creates in monalisa-news-api, so the page
// looks the same whether or not the API is actually running.
const FALLBACK_ENTRIES: LiveEntry[] = [
  { id: "fb4", tag: "Just In", title: "Draft framework formally signed by 38 of 42 delegations", body: "Officials confirmed the signing moments ago in the main plenary hall.", postedAt: new Date(Date.now() - 5 * 60_000).toISOString() },
  { id: "fb3", title: "Closing plenary pushed back by 90 minutes", body: "Organizers say the delay is procedural, giving legal teams more time to finalize the framework's text.", postedAt: new Date(Date.now() - 40 * 60_000).toISOString() },
  { id: "fb2", title: "Coastal-infrastructure fund reportedly set at an initial $2.4B", body: "Two delegation officials separately described the figure as a starting commitment.", postedAt: new Date(Date.now() - 90 * 60_000).toISOString() },
  { id: "fb1", tag: "Blog Start", title: "Welcome to our live coverage of the summit's closing day", body: "Our World Desk team is on the ground in Nairobi as negotiators aim to finalize the draft carbon-pricing framework.", postedAt: new Date(Date.now() - 180 * 60_000).toISOString() },
];

export default async function LiveBlogPage() {
  // Previously this page was 100% hardcoded and never called the API or
  // the WebSocket gateway at all — fixed to actually fetch, with the same
  // API-first / mock-fallback pattern used by resolveCategory().
  let liveBlog: { id: string; title: string; summary: string; entries: LiveEntry[] } | null = null;
  try {
    liveBlog = (await apiClient.getLiveBlog(SLUG)) as typeof liveBlog;
  } catch {
    liveBlog = null;
  }

  const title = liveBlog?.title ?? "Climate Summit Closing Day: Live Updates as Negotiators Finalize the Framework";
  const summary = liveBlog?.summary ?? "Rolling coverage from Nairobi as delegations move toward a final agreement.";
  const entries = liveBlog?.entries ?? FALLBACK_ENTRIES;
  const liveBlogId = liveBlog?.id ?? SLUG; // falls back to the slug as the WS room name if the API is down

  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase px-2 py-0.5 rounded bg-red text-white">
        <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> Live
      </span>
      <h1 className="text-2xl sm:text-4xl font-black mt-2 leading-tight text-navy">{title}</h1>
      <p className="text-sm text-gray-600 mt-2 max-w-2xl">{summary}</p>

      <div className="mt-8">
        <LiveEntries liveBlogId={liveBlogId} slug={SLUG} initialEntries={entries} />
      </div>
    </div>
  );
}
