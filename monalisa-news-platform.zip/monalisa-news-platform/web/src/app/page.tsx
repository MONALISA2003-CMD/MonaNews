import Image from "next/image";
import Link from "next/link";
import Badge from "@/components/Badge";
import StoryCard from "@/components/StoryCard";
import { CATEGORIES } from "@/data/categories";

export default function HomePage() {
  const politics = CATEGORIES.politics;
  const business = CATEGORIES.business;
  const sports = CATEGORIES.sports;
  const climate = CATEGORIES.climate;
  const opinion = CATEGORIES.opinion;
  const [heroStory, ...topStories] = politics.stories;

  return (
    <>
      {/* Breaking news bar */}
      <div className="bg-red text-white">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 h-9 flex items-center gap-4 text-xs overflow-x-auto">
          <span className="font-bold flex items-center gap-1 shrink-0">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="white">
              <path d="M13 2L3 14h7l-1 8 10-12h-7z" />
            </svg>
            BREAKING NEWS
          </span>
          {CATEGORIES.breakingnews.stories.map((s) => (
            <span key={s.slug} className="flex items-center gap-2 shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-white" /> {s.headline}{" "}
              <span className="opacity-70">{s.meta.split(" · ")[0]}</span>
            </span>
          ))}
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-6 grid lg:grid-cols-[1fr_340px] gap-6">
        <div>
          {/* Hero */}
          <div className="relative rounded-lg overflow-hidden">
            <div className="relative aspect-[16/9] w-full">
              <Image src={`https://picsum.photos/seed/${heroStory.seed}/1100/620`} alt="" fill className="object-cover" priority />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />
            <Badge color="bg-blue" className="absolute top-4 left-4">
              Top Story
            </Badge>
            <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-7 text-white">
              <h1 className="text-2xl sm:text-4xl font-black leading-tight max-w-xl">{heroStory.headline}</h1>
              <div className="flex items-center gap-3 mt-5">
                <Link href={`/article/${heroStory.slug}`} className="bg-red text-white text-sm font-semibold px-5 py-2.5 rounded-md hover:opacity-90">
                  Read Full Story
                </Link>
              </div>
            </div>
          </div>

          {/* Top stories */}
          <div className="mt-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-black tracking-tight">TOP STORIES</h2>
              <Link href="/category/politics" className="text-sm font-semibold text-blue hover:underline">
                View All
              </Link>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {topStories.slice(0, 4).map((s) => (
                <StoryCard key={s.slug} story={s} />
              ))}
            </div>
          </div>

          {/* Business */}
          <div className="mt-10">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-black tracking-tight">BUSINESS</h2>
              <Link href="/category/business" className="text-sm font-semibold text-blue hover:underline">
                View All
              </Link>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {business.stories.slice(0, 3).map((s) => (
                <StoryCard key={s.slug} story={s} />
              ))}
            </div>
          </div>

          {/* Sports */}
          <div className="mt-10">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-black tracking-tight">SPORTS</h2>
              <Link href="/category/sports" className="text-sm font-semibold text-blue hover:underline">
                View All
              </Link>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {sports.stories.slice(0, 3).map((s) => (
                <StoryCard key={s.slug} story={s} />
              ))}
            </div>
          </div>

          {/* Climate feature band */}
          <div className="mt-10 bg-navy text-white rounded-lg p-6 sm:p-8 grid sm:grid-cols-2 gap-6 items-center">
            <div>
              <span className="text-xs font-bold tracking-wide" style={{ color: "#7FA8D9" }}>
                CLIMATE &amp; ENVIRONMENT
              </span>
              <h2 className="text-2xl font-black mt-2 leading-tight">{climate.stories[0].headline}</h2>
              <Link href="/category/climate" className="inline-block mt-4 text-sm font-semibold border-b-2 border-red pb-1">
                Read the full story →
              </Link>
            </div>
            <div className="relative aspect-[7/5] w-full rounded-md overflow-hidden">
              <Image src={`https://picsum.photos/seed/${climate.stories[0].seed}/700/500`} alt="" fill className="object-cover" />
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <aside className="flex flex-col gap-4">
          <div className="card p-4">
            <h2 className="text-sm font-black tracking-tight mb-3">MOST READ</h2>
            <ol className="space-y-3">
              {politics.stories.slice(0, 5).map((s, i) => (
                <li key={s.slug} className="flex items-center gap-3">
                  <span className="w-5 h-5 bg-navy text-white text-xs font-bold rounded flex items-center justify-center shrink-0">
                    {i + 1}
                  </span>
                  <Link href={`/category/${politics.slug}`} className="text-xs flex-1 hover:text-red transition-colors">
                    {s.headline}
                  </Link>
                </li>
              ))}
            </ol>
          </div>

          <div className="card p-4">
            <h2 className="text-sm font-black tracking-tight mb-3">OPINION</h2>
            <ul className="space-y-3">
              {opinion.stories.slice(0, 3).map((s) => (
                <li key={s.slug}>
                  <Link href="/category/opinion" className="text-sm font-semibold hover:text-red transition-colors">
                    {s.headline}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-navy text-white rounded-lg p-5">
            <h3 className="text-base font-black leading-tight">Morning Brief</h3>
            <p className="text-xs text-white/70 mt-2">
              The stories that matter, in a five-minute read, every weekday morning.
            </p>
            <form className="flex gap-2 mt-3">
              <input
                type="email"
                required
                placeholder="Email address"
                className="flex-1 min-w-0 rounded-md px-3 py-2 text-xs text-ink bg-white"
              />
              <button className="bg-red text-white text-xs font-semibold px-3 py-2 rounded-md hover:opacity-90 shrink-0">
                Sign up
              </button>
            </form>
          </div>
        </aside>
      </div>
    </>
  );
}
