import type { Author } from "@/lib/types";

// Mock author records. In production this maps to the User model in
// prisma/schema.prisma (role IN journalist/editor/etc.) and would be
// fetched from the database — see authors.module.ts on the API side.
export const AUTHORS: Record<string, Author> = {
  "aisha-namboga": {
    slug: "aisha-namboga",
    name: "Aisha Namboga",
    beat: "Diplomacy & Climate Policy",
    bio: "Covers international diplomacy and climate policy for the World Desk. Based between Nairobi and Kampala, she has reported from summits and negotiating rooms across East Africa for the past eight years.",
    basedIn: "Nairobi / Kampala",
    joined: "2018",
    articleCount: 312,
  },
  "john-mulusimbi": {
    slug: "john-mulusimbi",
    name: "John Mulusimbi",
    beat: "Politics & Policy",
    bio: "Covers Parliament, elections, and government policy. Previously covered East African Community affairs for a regional wire service before joining Monalisa News in 2020.",
    basedIn: "Kampala",
    joined: "2020",
    articleCount: 248,
  },
  "diana-nakate": {
    slug: "diana-nakate",
    name: "Diana Nakate",
    beat: "Business & Trade",
    bio: "Reports on trade, banking, and the regional economy. Holds a background in financial journalism and has covered three East African Community trade summits.",
    basedIn: "Kampala",
    joined: "2019",
    articleCount: 271,
  },
  "brian-tumwesigye": {
    slug: "brian-tumwesigye",
    name: "Brian Tumwesigye",
    beat: "Technology & AI",
    bio: "Covers technology, artificial intelligence, and digital policy. Formerly worked in software before moving into journalism to cover the industry he came from.",
    basedIn: "Kampala",
    joined: "2021",
    articleCount: 156,
  },
  "denis-muwanga": {
    slug: "denis-muwanga",
    name: "Denis Muwanga",
    beat: "Sports",
    bio: "Covers regional football and East African athletics. Has reported from three AFCON qualifying campaigns and covers the Uganda Cranes home and away.",
    basedIn: "Kampala",
    joined: "2017",
    articleCount: 389,
  },
};

export function getAuthor(slug: string): Author {
  return AUTHORS[slug] ?? AUTHORS["aisha-namboga"];
}
