import { getCategory, CATEGORIES, CATEGORY_LIST } from "./categories";

describe("getCategory", () => {
  it("returns the matching category for a known slug", () => {
    expect(getCategory("politics").title).toBe("Politics");
  });

  it("falls back to politics for an unknown slug instead of throwing", () => {
    expect(getCategory("not-a-real-category").slug).toBe("politics");
  });
});

describe("CATEGORIES", () => {
  it("contains all 25 sections from the brief", () => {
    expect(CATEGORY_LIST.length).toBe(25);
  });

  it("every category has at least one story", () => {
    for (const cat of CATEGORY_LIST) {
      expect(cat.stories.length).toBeGreaterThan(0);
    }
  });

  it("every category slug matches its own key in the map", () => {
    for (const [key, cat] of Object.entries(CATEGORIES)) {
      expect(cat.slug).toBe(key);
    }
  });
});
