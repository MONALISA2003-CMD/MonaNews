import type { BadgeColor } from "./types";

export interface ArticleSection {
  id: string;
  heading: string;
  paragraphs: string[];
}

export interface FullArticle {
  slug: string;
  headline: string;
  dek: string;
  authorSlug: string;
  categorySlug: string;
  categoryTitle: string;
  badge: BadgeColor;
  heroSeed: string;
  publishedAt: string; // ISO date
  readingTimeMin: number;
  sections: ArticleSection[];
  tags: string[];
}

// A small set of fully-written articles, versus the ~110 headline-only
// stories in categories.ts. resolveArticle() in this file falls back to a
// lighter generic render for any story slug that isn't one of these —
// see that function's comment for why, rather than pretending every
// headline in the site is a unique long-form piece.
export const ARTICLES: Record<string, FullArticle> = {
  "climate-summit": {
    slug: "climate-summit",
    headline: "Global Leaders Unite At Climate Summit To Tackle Rising Environmental Threats",
    dek: "World leaders have gathered in Nairobi for a historic climate summit aimed at accelerating global action on climate change and sustainable development.",
    authorSlug: "aisha-namboga",
    categorySlug: "climate",
    categoryTitle: "Climate & Environment",
    badge: "bg-blue",
    heroSeed: "monalisa-hero",
    publishedAt: "2026-07-17",
    readingTimeMin: 5,
    tags: ["Climate Summit", "Nairobi", "Carbon Pricing", "World Leaders"],
    sections: [
      {
        id: "sec1",
        heading: "A historic gathering",
        paragraphs: [
          "Delegations from more than 40 countries arrived in Nairobi this week for what organizers are calling the most consequential climate summit in nearly a decade. Talks opened Tuesday with closed-door sessions among finance ministers before expanding to full plenary discussions on Wednesday.",
          'The gathering comes as several regions report record-breaking heat and increasingly erratic rainfall, adding urgency to a negotiating process that has moved slowly in recent years. Officials from the host nation described the mood in the opening sessions as "cautiously constructive," though several delegations cautioned against premature optimism.',
        ],
      },
      {
        id: "sec2",
        heading: "What was agreed",
        paragraphs: [
          "By early Friday, negotiators had signed off on a draft framework for cross-border carbon pricing, along with a set of shared reporting standards intended to make national emissions data easier to compare. The framework still requires ratification by individual governments, a process several finance ministries say could stretch well into next year.",
          "A smaller group of nations also agreed to a joint fund aimed at supporting coastal infrastructure projects, though the total size of the fund and its funding sources remain under discussion.",
        ],
      },
      {
        id: "sec3",
        heading: "Sticking points",
        paragraphs: [
          "Not every issue on the agenda saw progress. Talks over financing timelines remained deadlocked through much of the week, with several lower-income nations pushing for faster disbursement schedules than wealthier nations have been willing to commit to.",
          "Observers also noted that enforcement mechanisms for the new reporting standards remain vague, with the current draft relying largely on voluntary compliance and peer review rather than binding penalties.",
        ],
      },
      {
        id: "sec4",
        heading: "What happens next",
        paragraphs: [
          "The draft agreement now moves to individual governments for review and, in many cases, legislative approval. A follow-up session is expected before the end of the year to assess how many signatories have taken formal steps toward ratification.",
          "For now, organizers say the framework represents genuine, if incomplete, progress — a foundation that future summits can build on rather than a finished product.",
        ],
      },
    ],
  },

  "coalition-talks-cabinet-seats": {
    slug: "coalition-talks-cabinet-seats",
    headline: "Coalition talks enter final stretch as smaller parties press for cabinet seats",
    dek: "With days left before the formal deadline, negotiations between the leading coalition partners and three smaller parties have intensified over how ministerial posts will be divided.",
    authorSlug: "john-mulusimbi",
    categorySlug: "politics",
    categoryTitle: "Politics",
    badge: "bg-navy",
    heroSeed: "pol1",
    publishedAt: "2026-07-17",
    readingTimeMin: 4,
    tags: ["Coalition", "Cabinet", "Parliament"],
    sections: [
      {
        id: "sec1",
        heading: "Where talks stand",
        paragraphs: [
          "Negotiators for the two largest coalition partners met through the weekend with representatives of three smaller parties whose support is needed to confirm a working majority in Parliament. Both sides describe the talks as constructive, though no final list of ministerial appointments has been agreed.",
          "The smaller parties are pressing for at least two full cabinet posts and a deputy minister position, according to two people familiar with the discussions who were not authorized to speak publicly before an announcement.",
        ],
      },
      {
        id: "sec2",
        heading: "The sticking point",
        paragraphs: [
          "The main disagreement centers on which ministries would go to the smaller parties. Both sides confirm that finance and defense are considered off the table for the junior partners, narrowing the realistic options to a handful of mid-tier ministries.",
          "A senior official from the leading party said an announcement is expected \"within days, not weeks,\" though similar timelines have slipped before during past coalition talks.",
        ],
      },
      {
        id: "sec3",
        heading: "Why it matters",
        paragraphs: [
          "The final cabinet lineup will shape the government's legislative priorities for the coming term, particularly on the tax and infrastructure bills that were central to the campaign. A delayed or unstable coalition could also complicate the budget session scheduled for next month.",
        ],
      },
    ],
  },

  "uganda-exports-record": {
    slug: "uganda-exports-record",
    headline: "Uganda's exports reach record $6.2B in 2026",
    dek: "Coffee, gold, and fish exports lead the growth in the first half of the year, according to new trade data released this week.",
    authorSlug: "diana-nakate",
    categorySlug: "business",
    categoryTitle: "Business",
    badge: "bg-red",
    heroSeed: "biz1",
    publishedAt: "2026-07-16",
    readingTimeMin: 3,
    tags: ["Trade", "Exports", "Coffee", "Gold"],
    sections: [
      {
        id: "sec1",
        heading: "The numbers",
        paragraphs: [
          "Export earnings reached $6.2 billion in the first half of 2026, a record for the period and an increase of roughly 14% over the same stretch last year, according to figures released by trade officials this week.",
          "Coffee remained the single largest export by value, followed by gold and fish products. Officials credited a combination of favorable global prices and expanded processing capacity for the gains.",
        ],
      },
      {
        id: "sec2",
        heading: "What's driving it",
        paragraphs: [
          "Coffee exporters point to two consecutive strong harvests and continued investment in value-added processing — roasting and packaging domestically rather than exporting raw beans — as a key factor in the increased earnings per unit shipped.",
          "Gold exports also grew, though industry analysts caution that gold figures can be volatile and are sensitive to global price swings that are largely outside domestic control.",
        ],
      },
      {
        id: "sec3",
        heading: "The caveats",
        paragraphs: [
          "Trade economists note that export growth has not been evenly distributed across sectors, and that manufactured goods — a policy priority for diversifying the export base — grew more slowly than raw and semi-processed commodities.",
          "Officials say a fuller breakdown, including manufactured goods figures, will be released alongside the full-year report expected early next year.",
        ],
      },
    ],
  },

  "ai-transform-jobs-education-healthcare": {
    slug: "ai-transform-jobs-education-healthcare",
    headline: "AI will transform jobs, education, and healthcare, experts say",
    dek: "A new sector-by-sector review argues that AI adoption is moving faster in service delivery than in manufacturing, with the clearest early gains in diagnostics and administrative work.",
    authorSlug: "brian-tumwesigye",
    categorySlug: "ai",
    categoryTitle: "Artificial Intelligence",
    badge: "bg-purple",
    heroSeed: "ai1",
    publishedAt: "2026-07-15",
    readingTimeMin: 5,
    tags: ["AI", "Healthcare", "Education", "Jobs"],
    sections: [
      {
        id: "sec1",
        heading: "Where adoption is happening fastest",
        paragraphs: [
          "A review compiled by a panel of regional technology researchers finds that AI-assisted tools are being adopted fastest in diagnostic medicine and administrative processing — areas where a tool that flags likely problems for a human to review, rather than one that acts autonomously, is both easier to trust and easier to regulate.",
          "Several hospitals in the region have expanded pilot programs for AI-assisted radiology review over the past year, with clinicians describing the tools as most useful for triage — flagging cases that need urgent attention — rather than as a replacement for a specialist's final read.",
        ],
      },
      {
        id: "sec2",
        heading: "Education is moving more cautiously",
        paragraphs: [
          "Universities in the review report a more cautious rollout, largely centered on reworking how coursework is assessed now that AI writing tools are in common use among students, rather than on adopting AI as a teaching tool itself.",
          "\"The technology moved faster than our assessment methods did,\" one university administrator quoted in the review said, describing a shift toward in-class and oral assessment components alongside traditional written work.",
        ],
      },
      {
        id: "sec3",
        heading: "The jobs question",
        paragraphs: [
          "On employment, the review is more measured than some industry forecasts, finding that AI adoption so far has mostly changed how existing jobs are done — automating specific administrative tasks — rather than eliminating job categories outright, at least in the sectors studied.",
          "Researchers caution that this could change as adoption matures, and recommend that policymakers begin discussing retraining programs now rather than waiting for displacement to become visible in employment data.",
        ],
      },
    ],
  },

  "uganda-cranes-afcon-2027": {
    slug: "uganda-cranes-afcon-2027",
    headline: "Uganda Cranes qualify for AFCON 2027",
    dek: "The Cranes secure a strong win against South Sudan in the final qualifier, sealing their spot in next year's tournament.",
    authorSlug: "denis-muwanga",
    categorySlug: "sports",
    categoryTitle: "Sports",
    badge: "bg-green",
    heroSeed: "spo1",
    publishedAt: "2026-07-14",
    readingTimeMin: 3,
    tags: ["AFCON", "Uganda Cranes", "Football"],
    sections: [
      {
        id: "sec1",
        heading: "The result",
        paragraphs: [
          "Uganda booked their place at next year's Africa Cup of Nations with a 2-1 win over South Sudan in Wednesday's final qualifier, finishing the qualifying campaign unbeaten at home.",
          "Goals either side of half-time settled the contest, with the home side controlling long stretches of the second half despite a late South Sudan goal that briefly threatened a nervous finish.",
        ],
      },
      {
        id: "sec2",
        heading: "The bigger picture",
        paragraphs: [
          "This is the Cranes' third consecutive AFCON qualification, a run the federation has pointed to as evidence of a more settled squad and coaching setup compared to the turnover of previous years.",
          "The team's coach said after the match that the focus now shifts to friendly fixtures over the coming months to test squad depth ahead of the tournament draw.",
        ],
      },
      {
        id: "sec3",
        heading: "What's next",
        paragraphs: [
          "The draw for the tournament proper is expected later this year. Federation officials say ticket and travel planning for supporters will be announced once the group stage fixtures are confirmed.",
        ],
      },
    ],
  },
};

export function findFullArticle(slug: string): FullArticle | null {
  return ARTICLES[slug] ?? null;
}

export const ARTICLE_LIST = Object.values(ARTICLES);
