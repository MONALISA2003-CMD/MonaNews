import type { BadgeColor } from "@/lib/types";

export default function Badge({
  color,
  children,
  className = "",
}: {
  color: BadgeColor;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={`inline-block text-[11px] font-bold tracking-wide uppercase px-2 py-0.5 rounded text-white ${color} ${className}`}
    >
      {children}
    </span>
  );
}
