"use client";

import Link from "next/link";
import { useAuth } from "@/lib/auth";

export default function AuthStatus() {
  const { user, loading, logout } = useAuth();

  if (loading) return <div className="w-16 h-8" />; // avoid layout shift while checking

  if (user) {
    return (
      <div className="hidden sm:flex items-center gap-3 text-sm">
        <span className="font-semibold text-navy">{user.name.split(" ")[0]}</span>
        <button onClick={logout} className="text-gray-500 hover:text-red">
          Sign Out
        </button>
      </div>
    );
  }

  return (
    <Link
      href="/login"
      className="hidden sm:inline-block border border-blue text-blue text-sm font-semibold px-4 py-2 rounded-md hover:bg-blue hover:text-white transition"
    >
      Sign In
    </Link>
  );
}
