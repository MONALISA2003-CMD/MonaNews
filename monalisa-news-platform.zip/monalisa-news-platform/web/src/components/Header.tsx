import Link from "next/link";
import DarkModeToggle from "./DarkModeToggle";
import Nav from "./Nav";
import AuthStatus from "./AuthStatus";

export default function Header() {
  return (
    <header className="bg-white border-b border-line sticky top-0 z-40">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-6">
        <Link href="/" className="shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-2xl sm:text-3xl font-black tracking-tight text-navy">MONALISA</span>
            <span className="bg-red text-white text-2xl sm:text-3xl font-black px-2 rounded-sm">NEWS</span>
          </div>
          <p className="text-xs text-gray-500 mt-0.5">Real News. Real Impact.</p>
        </Link>

        <form action="/search" className="hidden md:flex flex-1 max-w-md">
          <div className="flex items-center w-full border border-line rounded-full px-4 py-2 gap-2">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="shrink-0">
              <circle cx="11" cy="11" r="7" stroke="#9CA3AF" strokeWidth="2" />
              <path d="M21 21l-4.3-4.3" stroke="#9CA3AF" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <input
              name="q"
              type="text"
              placeholder="Search news, topics, people..."
              className="flex-1 outline-none text-sm bg-transparent"
            />
          </div>
        </form>

        <div className="flex items-center gap-4 shrink-0">
          <Link href="/search" className="md:hidden p-2" aria-label="Search">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <circle cx="11" cy="11" r="7" stroke="#111827" strokeWidth="2" />
              <path d="M21 21l-4.3-4.3" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </Link>
          <DarkModeToggle />
          <AuthStatus />
          <button className="bg-red text-white text-sm font-semibold px-4 py-2 rounded-md hover:opacity-90">
            Subscribe
          </button>
        </div>
      </div>
      <Nav />
    </header>
  );
}
