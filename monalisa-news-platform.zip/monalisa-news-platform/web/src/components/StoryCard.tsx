import Image from "next/image";
import Link from "next/link";
import Badge from "./Badge";
import type { Story } from "@/lib/types";

export default function StoryCard({ story, href }: { story: Story; href?: string }) {
  const target = href ?? `/article/${story.slug}`;
  return (
    <Link href={target} className="group card overflow-hidden block bg-white border border-line rounded-lg">
      <div className="relative aspect-[3/2] w-full">
        <Image
          src={`https://picsum.photos/seed/${story.seed}/420/260`}
          alt=""
          fill
          className="object-cover"
        />
      </div>
      <div className="p-3">
        <Badge color={story.badge}>{story.label}</Badge>
        <h3 className="font-bold leading-snug mt-2 group-hover:text-red transition-colors">
          {story.headline}
        </h3>
        <span className="text-xs text-gray-500 block mt-2">{story.meta}</span>
      </div>
    </Link>
  );
}
