"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const PRIMARY_LINKS: { href: string; label: string; cat?: string }[] = [
  { href: "/category/breakingnews", label: "Breaking News", cat: "breakingnews" },
  { href: "/category/politics", label: "Politics", cat: "politics" },
  { href: "/category/business", label: "Business", cat: "business" },
  { href: "/category/technology", label: "Technology", cat: "technology" },
  { href: "/category/ai", label: "Artificial Intelligence", cat: "ai" },
  { href: "/category/cybersecurity", label: "Cybersecurity", cat: "cybersecurity" },
  { href: "/category/science", label: "Science", cat: "science" },
  { href: "/category/health", label: "Health", cat: "health" },
  { href: "/category/sports", label: "Sports", cat: "sports" },
  { href: "/category/entertainment", label: "Entertainment", cat: "entertainment" },
  { href: "/category/africa", label: "Africa", cat: "africa" },
  { href: "/category/world", label: "World", cat: "world" },
  { href: "/category/climate", label: "Climate", cat: "climate" },
  { href: "/category/opinion", label: "Opinion", cat: "opinion" },
  { href: "/category/investigations", label: "Investigations", cat: "investigations" },
  { href: "/video-hub", label: "Watch & Listen" },
  { href: "/live-blog", label: "Live Blog" },
  { href: "/markets", label: "Markets" },
  { href: "/newsletters", label: "Newsletters" },
  { href: "/sections", label: "All Sections" },
];

export default function Nav() {
  const pathname = usePathname();

  return (
    <nav className="bg-navy">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 flex items-center gap-1 h-11 text-sm font-medium text-white overflow-x-auto">
        <Link href="/" className="px-3 h-11 flex items-center shrink-0" aria-label="Home">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
            <path d="M12 3l9 8h-3v9h-5v-6H11v6H6v-9H3z" />
          </svg>
        </Link>
        {PRIMARY_LINKS.map((link) => {
          const active = pathname === link.href;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`px-3 h-11 flex items-center whitespace-nowrap transition-colors ${
                active ? "bg-red font-semibold" : "hover:text-red-300"
              }`}
            >
              {link.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
