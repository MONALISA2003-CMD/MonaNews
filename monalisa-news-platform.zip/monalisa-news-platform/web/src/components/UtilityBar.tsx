export default function UtilityBar() {
  return (
    <div className="bg-navy text-white text-xs">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 flex items-center justify-between h-9">
        <div className="flex items-center gap-3">
          {/* Server-rendered placeholder date — swap for a real formatted server date */}
          <span className="opacity-70 hidden sm:inline">Thursday, July 17, 2026</span>
          <span className="bg-red text-white font-bold px-2 py-0.5 rounded-sm flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> LIVE
          </span>
          {/* TODO: wire to a real weather API (see prisma schema note on external data) */}
          <span className="opacity-80 hidden sm:inline">Nairobi 22°C ☁️</span>
        </div>
        <div className="hidden md:flex items-center gap-4 opacity-90">
          <a href="#" className="hover:opacity-100">About Us</a>
          <a href="#" className="hover:opacity-100">Contact</a>
          <a href="#" className="hover:opacity-100">Advertise</a>
        </div>
      </div>
    </div>
  );
}
