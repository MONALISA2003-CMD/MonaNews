"use client";

import { useState, useEffect } from "react";

export default function DarkModeToggle() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <div className="hidden sm:flex items-center gap-2 text-sm text-gray-600">
      <span>Dark Mode</span>
      <button
        role="switch"
        aria-checked={dark}
        aria-label="Toggle dark mode"
        onClick={() => setDark((d) => !d)}
        className={`w-[38px] h-5 rounded-full relative transition-colors ${
          dark ? "bg-navy" : "bg-gray-300"
        }`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
            dark ? "translate-x-[18px]" : ""
          }`}
        />
      </button>
    </div>
  );
}
