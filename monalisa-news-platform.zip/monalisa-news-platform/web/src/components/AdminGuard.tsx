"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";

// Every role except SUBSCRIBER and ADVERTISER can at least view the CMS
// shell — individual actions (publish, archive, etc.) are still gated more
// specifically by the API's RolesGuard per-endpoint. This is a coarse
// "should this person even see the admin UI" check, not the real security
// boundary — that's always the API, which rejects unauthorized writes
// regardless of what this guard does. This guard exists so an
// unauthenticated visitor can't casually load /admin/articles/new and
// see the CMS shell at all, which is what was happening before.
const STAFF_ROLES = new Set([
  "SUPER_ADMIN",
  "EDITOR_IN_CHIEF",
  "EDITOR",
  "JOURNALIST",
  "FACT_CHECKER",
  "MODERATOR",
  "PHOTOGRAPHER",
  "VIDEO_EDITOR",
  "PODCAST_PRODUCER",
]);

export default function AdminGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!user || !STAFF_ROLES.has(user.role)) {
      router.replace("/login?next=/admin");
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-sm text-gray-400">
        Checking access…
      </div>
    );
  }

  if (!user || !STAFF_ROLES.has(user.role)) {
    // Brief flash before the redirect above fires — better than rendering
    // the CMS shell itself in that window.
    return (
      <div className="min-h-screen flex items-center justify-center text-sm text-gray-400">
        Redirecting to sign in…
      </div>
    );
  }

  return <>{children}</>;
}
