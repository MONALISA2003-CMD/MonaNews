export default function Footer() {
  return (
    <footer className="bg-navy text-white/80 mt-6">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/50">
        <span>
          © 2026 Monalisa News. All Rights Reserved. — Developed by{" "}
          <a
            href="https://wa.me/19138992840"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white/80 hover:text-white underline"
          >
            MONALISA TECH SOLUTIONS
          </a>{" "}
          ·{" "}
          <a href="mailto:kabuusumohammed182@gmail.com" className="text-white/80 hover:text-white underline">
            kabuusumohammed182@gmail.com
          </a>
        </span>
        <span>
          Made with <span className="text-red">❤</span> in Africa
        </span>
      </div>
    </footer>
  );
}
