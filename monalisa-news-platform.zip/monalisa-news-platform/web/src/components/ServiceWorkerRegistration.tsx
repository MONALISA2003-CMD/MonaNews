"use client";

import { useEffect } from "react";

export default function ServiceWorkerRegistration() {
  useEffect(() => {
    if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      // Only register in production — in dev, Next.js's own fast refresh
      // and the service worker's caching fight each other and make it
      // look like changes aren't taking effect.
      navigator.serviceWorker.register("/sw.js").catch(() => {
        // Fails silently — offline support degrading isn't worth
        // interrupting anyone's session over.
      });
    }
  }, []);

  return null;
}
