import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        navy: "#0E1B33",
        "navy-2": "#152747",
        red: "#DA1E28",
        "red-2": "#B0151D",
        blue: "#1D5FA8",
        green: "#1E8449",
        purple: "#6B3FA0",
        teal: "#0E7C86",
        orange: "#C2660D",
        "gray-bg": "#F3F4F6",
        line: "#E5E7EB",
        ink: "#111827",
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
    },
  },
  darkMode: "class",
  plugins: [],
};
export default config;
