# Monalisa News — Next.js + CMS Phase

This is the real, runnable-once-installed Next.js 15 (App Router) + TypeScript
+ Tailwind codebase for Monalisa News, plus the Prisma schema for the
newsroom CMS described in the original brief.

**I could not run `npm install` or a dev server in the sandbox this was
built in — it has no network access.** Everything here is written to be
correct, idiomatic Next.js/TypeScript that should run as-is once you `npm
install` locally, but it has not been compiled or tested by a live build.
Treat the first `npm run dev` as your first real test pass, and expect to
fix the occasional small thing (a version-specific API shape, a missing
peer dependency) the way you would with any freshly scaffolded project.

## Getting started

```bash
npm install
cp .env.example .env      # fill in a real DATABASE_URL if using Prisma
npm run dev                # http://localhost:3000
```

To use the CMS data layer for real (optional — the site runs on mock data
without it):

```bash
# requires a running PostgreSQL instance
npx prisma migrate dev --name init
npx prisma generate
```

## What's real vs. mocked

**Real, production-shaped code:**
- App Router structure, layouts, and routing (`src/app/**`)
- Shared components (`Header`, `Nav`, `Footer`, `StoryCard`, `Badge`)
- The dynamic category route (`/category/[slug]`) — one template statically
  generates all 25 sections via `generateStaticParams()`
- Client-side interactive components (dark mode, reading progress, text
  size, save/bookmark, search filtering) using real React state — not the
  manual DOM manipulation the earlier static-HTML prototype used
- `prisma/schema.prisma` — a complete, realistic data model: users/roles,
  articles with full revision history, categories, tags, media, comments,
  live blogs, newsletters, audit log

**Mocked (clearly marked in code with comments):**
- `src/data/categories.ts` and `src/data/authors.ts` stand in for database
  queries. They're typed the same way real Prisma query results would be,
  so swapping them for `prisma.category.findMany()` etc. is a drop-in
  change, not a rewrite.
- Market prices, weather, live sports scores, live-blog entries — all
  static arrays. Real versions need actual data providers.
- The admin CMS pages (`src/app/admin/**`) are UI only — forms don't
  persist anywhere, "AI Assist" buttons show what they'd do rather than
  calling a model.
- Auth: there's no real login. `role`-based UI (e.g. who can publish) exists
  only in the Prisma schema, not enforced anywhere yet.

## Connecting to the real API

`src/lib/api-client.ts` is a typed fetch client for every endpoint in
`monalisa-news-api`. It is **not wired into any page yet** — every page
still reads from `src/data/categories.ts` / `src/data/authors.ts` so the
site keeps working with zero backend. To connect a page for real:

```ts
// before (mock data, works standalone)
import { getCategory } from "@/data/categories";
const cat = getCategory(slug);

// after (real API, requires monalisa-news-api running)
import { apiClient } from "@/lib/api-client";
const cat = await apiClient.getCategory(slug);
```

Set `NEXT_PUBLIC_API_URL` (see `.env.local.example`) to point at a running
instance of `monalisa-news-api`.

## Running the full stack with Docker

See `monalisa-news-platform/docker-compose.yml` (one level up, alongside
this project and `monalisa-news-api`) to run Postgres, Redis, the API, and
this front-end together with one command:

```bash
docker compose up --build
```

## What's still needed for a real deployment

- **Auth**: NextAuth.js (or similar) wired to the `User`/`Role` model
- **API layer**: route handlers or a separate NestJS service reading/writing
  through Prisma instead of the static `src/data` files
- **Search**: Elasticsearch/OpenSearch or pgvector, per the original brief
- **AI features**: real calls to an LLM provider for summaries, fact-check
  assist, tag suggestions — the admin editor has the UI hooks already
- **Media storage**: S3-compatible bucket instead of picsum.photos placeholders
- **Hosting**: Vercel, or Docker + your own infra (a `Dockerfile` isn't
  included yet — ask if you want one)

## Structure

```
src/
  app/                    # routes (App Router)
    admin/                # CMS console (dashboard, articles, media)
    article/[slug]/
    author/[slug]/
    category/[slug]/      # one template, all 25 sections
    live-blog/
    markets/
    newsletters/
    search/
    sections/
    video-hub/
  components/             # Header, Nav, Footer, Badge, StoryCard
  data/                   # mock data layer (categories.ts, authors.ts)
  lib/types.ts            # shared TypeScript types
prisma/
  schema.prisma           # full CMS data model
```
