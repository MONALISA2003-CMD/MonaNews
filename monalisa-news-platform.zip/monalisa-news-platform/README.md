# Monalisa News — Full Stack

This folder is the earlier deliverables assembled to actually run
together: `web/` (Next.js front-end), `api/` (NestJS + Prisma API),
`firebase/` (Gemini-powered AI Cloud Functions), and a `docker-compose.yml`
wiring `web`/`api` to Postgres and Redis. `firebase/` deploys separately
(see below) since Firebase Functions isn't a Docker Compose service.

**Same standing disclaimer as every package before this one:** built with
no network access, so `docker compose up` has not actually been run here.
The Dockerfiles and compose file are written correctly as far as careful
manual review can confirm — this is the first real end-to-end test of the
whole stack, not a guarantee it's bug-free.

## Run it

**Deploying this for real?** See `DEPLOY.md` for the step-by-step
Vercel + Render + Firebase path (the free-tier option discussed in chat,
including exactly where its real limits are). What follows below is for
running everything locally with Docker instead.


```bash
docker compose up --build
```

This will:
1. Start Postgres and Redis
2. Build and start the API, run `prisma migrate deploy` + `prisma db seed`
   automatically on boot (loads the 25 categories, 5 newsletters, and one
   sample editor account), then start listening on `:4000`
3. Build and start the Next.js app on `:3000`

Then:
- Front-end: **http://localhost:3000** (still runs on its own mock data by
  default — see `web/README.md` for wiring pages to the live API)
- API: **http://localhost:4000/api/v1** (e.g. `GET /api/v1/categories`)

## Why the front-end doesn't call the API by default

The Next.js app was built to work standalone (no backend required) so it's
useful on its own. `web/src/lib/api-client.ts` is the real, typed client
for every API endpoint — swapping a page from the static `src/data/*.ts`
files to live API calls is a small, deliberate change per page (shown in
`web/README.md`), not a flag to flip. That's a safer migration path than
making the whole site depend on the API being up before it's actually
ready.

## AI features (Gemini via Firebase Functions)

```bash
cd firebase/functions
npm install
firebase functions:secrets:set GEMINI_API_KEY   # free key: https://aistudio.google.com/app/apikey
firebase deploy --only functions
```

See `firebase/README.md` for the full function list and — importantly —
the note on `factCheckAssist` never asserting true/false (it triages for a
human fact-checker, since Gemini has no live web access here). Auth is now
unified: `api` verifies the same Firebase ID token these functions check,
so signing in once (`web/src/app/login`) authenticates everything — see
`api/README.md`'s Auth section for how the API auto-provisions a profile
row on first sign-in.

## What's genuinely missing before this is production-ready

- ~~A real AI provider integration~~ — done: see `firebase/` (Gemini via
  Cloud Functions). Still worth doing: add Google Search grounding before
  trusting `factCheckAssist` output for anything but human triage, and
  build an admin "manage users" screen instead of promoting roles via a
  direct database update.
- Elasticsearch/OpenSearch or pgvector for real search (current search
  is a Postgres `ILIKE` scan — fine for a demo, not for scale)
- A real market-data provider feeding Redis
- Object storage (S3-compatible) for uploaded media instead of picsum
  placeholders
- HTTPS/TLS termination, a reverse proxy (Cloudflare, per the original
  brief), and secrets management for `JWT_SECRET` / `DATABASE_URL` in
  production (the `.env` files here are for local development only)
- CI/CD (GitHub Actions was in the original brief — none included yet)

## Structure

```
monalisa-news-platform/
  docker-compose.yml
  api/            # NestJS + Prisma — see api/README.md
  web/            # Next.js + Tailwind — see web/README.md
  firebase/       # Gemini AI Cloud Functions — see firebase/README.md
```
